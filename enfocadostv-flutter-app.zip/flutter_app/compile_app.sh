#!/bin/bash

echo "📱 Compilación de Enfocados en Dios TV"
echo "======================================="
echo ""

# Colores
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
BLUE='\033[0;34m'
NC='\033[0m'

# Función para mostrar progreso
show_progress() {
    echo -e "${BLUE}⏳ $1...${NC}"
}

# Función para mostrar éxito
show_success() {
    echo -e "${GREEN}✅ $1${NC}"
}

# Función para mostrar error
show_error() {
    echo -e "${RED}❌ $1${NC}"
}

# Verificar que estamos en el directorio correcto
if [ ! -f "pubspec.yaml" ]; then
    show_error "No estás en el directorio del proyecto Flutter"
    echo "Ejecuta: cd /Users/jeviwayeirl/Desktop/enfocadosendiostv.com/flutter_app"
    exit 1
fi

# Verificar Flutter
if ! command -v flutter &> /dev/null; then
    show_error "Flutter no está instalado"
    echo "Primero ejecuta: ./install_flutter.sh"
    exit 1
fi

echo -e "${GREEN}Flutter encontrado:${NC}"
flutter --version
echo ""

# PASO 1: Limpiar proyecto
show_progress "Limpiando proyecto anterior"
flutter clean
show_success "Proyecto limpio"

# PASO 2: Obtener dependencias
show_progress "Instalando dependencias"
flutter pub get

# Verificar si build_runner está en las dependencias
if grep -q "build_runner:" pubspec.yaml; then
    show_progress "Generando código"
    flutter pub run build_runner build --delete-conflicting-outputs || true
fi

show_success "Dependencias instaladas"

# PASO 3: Verificar archivos de Firebase
echo ""
echo -e "${YELLOW}📋 Verificando configuración de Firebase:${NC}"

if [ -f "android/app/google-services.json" ]; then
    show_success "google-services.json encontrado"
else
    show_error "google-services.json NO encontrado"
    echo "El archivo ya debería estar en android/app/google-services.json"
fi

# PASO 4: Menú de compilación
echo ""
echo -e "${YELLOW}¿Qué tipo de APK deseas compilar?${NC}"
echo "1) Debug APK (rápido, para pruebas)"
echo "2) Release APK (optimizado, sin firma)"
echo "3) Release APK firmado (requiere keystore)"
echo "4) App Bundle para Play Store (requiere keystore)"
echo ""
read -p "Selecciona una opción [1-4]: " option

case $option in
    1)
        # Debug APK
        show_progress "Compilando Debug APK"
        flutter build apk --debug

        if [ $? -eq 0 ]; then
            show_success "APK Debug compilado exitosamente"
            APK_PATH="build/app/outputs/flutter-apk/app-debug.apk"
            APK_SIZE=$(du -h "$APK_PATH" | cut -f1)

            echo ""
            echo -e "${GREEN}📦 APK generado:${NC}"
            echo "Ubicación: $APK_PATH"
            echo "Tamaño: $APK_SIZE"
            echo ""
            echo -e "${YELLOW}Para instalar en tu teléfono Android:${NC}"
            echo "1. Conecta tu teléfono por USB"
            echo "2. Activa 'Depuración USB' en opciones de desarrollador"
            echo "3. Ejecuta: adb install $APK_PATH"
            echo ""
            echo "O transfiere el archivo APK a tu teléfono y ábrelo"

            # Abrir carpeta en Finder
            open build/app/outputs/flutter-apk/
        else
            show_error "Error al compilar APK Debug"
        fi
        ;;

    2)
        # Release APK sin firma
        show_progress "Compilando Release APK (sin firma)"
        flutter build apk --release --no-shrink

        if [ $? -eq 0 ]; then
            show_success "APK Release compilado (sin firma)"
            echo -e "${YELLOW}Nota: Este APK no está firmado y no se puede instalar directamente${NC}"
            echo "Necesitas firmarlo con un keystore"
        else
            show_error "Error al compilar APK Release"
        fi
        ;;

    3)
        # Release APK firmado
        if [ ! -f "android/key.properties" ]; then
            show_error "No se encontró android/key.properties"
            echo ""
            echo "Primero necesitas crear un keystore. Ejecuta:"
            echo "./create_keystore.sh"
            exit 1
        fi

        show_progress "Compilando Release APK firmado"
        flutter build apk --release --split-per-abi

        if [ $? -eq 0 ]; then
            show_success "APKs Release compilados exitosamente"
            echo ""
            echo -e "${GREEN}📦 APKs generados:${NC}"
            ls -lh build/app/outputs/flutter-apk/*.apk
            echo ""
            echo "Estos APKs están listos para distribución"

            # Abrir carpeta
            open build/app/outputs/flutter-apk/
        else
            show_error "Error al compilar APK Release"
        fi
        ;;

    4)
        # App Bundle para Play Store
        if [ ! -f "android/key.properties" ]; then
            show_error "No se encontró android/key.properties"
            echo ""
            echo "Primero necesitas crear un keystore. Ejecuta:"
            echo "./create_keystore.sh"
            exit 1
        fi

        show_progress "Compilando App Bundle para Play Store"
        flutter build appbundle --release

        if [ $? -eq 0 ]; then
            show_success "App Bundle compilado exitosamente"
            AAB_PATH="build/app/outputs/bundle/release/app-release.aab"
            AAB_SIZE=$(du -h "$AAB_PATH" | cut -f1)

            echo ""
            echo -e "${GREEN}📦 App Bundle generado:${NC}"
            echo "Ubicación: $AAB_PATH"
            echo "Tamaño: $AAB_SIZE"
            echo ""
            echo -e "${YELLOW}Este archivo está listo para subir a Google Play Console${NC}"
            echo ""
            echo "Próximos pasos:"
            echo "1. Ve a https://play.google.com/console"
            echo "2. Crea una nueva aplicación"
            echo "3. Sube el archivo .aab"

            # Abrir carpeta
            open build/app/outputs/bundle/release/
        else
            show_error "Error al compilar App Bundle"
        fi
        ;;

    *)
        echo "Opción no válida"
        ;;
esac

echo ""
echo -e "${GREEN}🎉 Proceso completado${NC}"