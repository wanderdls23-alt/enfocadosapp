#!/bin/bash

# Script de configuración completa para Enfocados en Dios TV Flutter App
# Este script instala todas las dependencias necesarias y prepara el proyecto

echo "🚀 Configuración de Enfocados en Dios TV - Mobile App"
echo "====================================================="
echo ""

# Colores para output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Función para mostrar progreso
show_progress() {
    echo -e "${BLUE}⏳ $1...${NC}"
}

# Función para mostrar éxito
show_success() {
    echo -e "${GREEN}✅ $1${NC}"
}

# Función para mostrar error
show_error() {
    echo -e "${RED}❌ $1${NC}"
}

# Verificar sistema operativo
OS="Unknown"
if [[ "$OSTYPE" == "darwin"* ]]; then
    OS="macOS"
elif [[ "$OSTYPE" == "linux-gnu"* ]]; then
    OS="Linux"
else
    show_error "Sistema operativo no soportado"
    exit 1
fi

echo "Sistema detectado: $OS"
echo ""

# 1. VERIFICAR HOMEBREW (macOS)
if [[ "$OS" == "macOS" ]]; then
    if ! command -v brew &> /dev/null; then
        show_progress "Instalando Homebrew"
        /bin/bash -c "$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/HEAD/install.sh)"
        show_success "Homebrew instalado"
    else
        show_success "Homebrew ya instalado"
    fi
fi

# 2. INSTALAR FLUTTER
if ! command -v flutter &> /dev/null; then
    show_progress "Instalando Flutter"

    if [[ "$OS" == "macOS" ]]; then
        # Instalar con Homebrew
        brew install --cask flutter
    else
        # Instalar manualmente en Linux
        cd ~
        git clone https://github.com/flutter/flutter.git -b stable
        echo 'export PATH="$PATH:$HOME/flutter/bin"' >> ~/.bashrc
        source ~/.bashrc
    fi

    show_success "Flutter instalado"
else
    show_success "Flutter ya instalado"
    flutter --version
fi

# 3. INSTALAR JAVA (para Android)
if ! command -v java &> /dev/null; then
    show_progress "Instalando Java"

    if [[ "$OS" == "macOS" ]]; then
        brew install openjdk@11
        echo 'export PATH="/usr/local/opt/openjdk@11/bin:$PATH"' >> ~/.zshrc
        source ~/.zshrc
    else
        sudo apt-get update
        sudo apt-get install -y openjdk-11-jdk
    fi

    show_success "Java instalado"
else
    show_success "Java ya instalado"
    java -version
fi

# 4. INSTALAR ANDROID STUDIO (Opcional pero recomendado)
echo ""
echo -e "${YELLOW}📱 Android Studio${NC}"
echo "Para el desarrollo de Android, necesitas Android Studio:"
echo "1. Descarga desde: https://developer.android.com/studio"
echo "2. Instala y configura Android SDK"
echo "3. Acepta las licencias de Android"
echo ""
read -p "¿Ya tienes Android Studio instalado? (s/n): " -n 1 -r
echo ""

if [[ ! $REPLY =~ ^[Ss]$ ]]; then
    echo -e "${YELLOW}Por favor, instala Android Studio antes de continuar${NC}"
    echo "URL: https://developer.android.com/studio"
    exit 1
fi

# 5. CONFIGURAR FLUTTER
show_progress "Configurando Flutter"

# Aceptar licencias de Android
flutter doctor --android-licenses

# Verificar instalación
flutter doctor

show_success "Flutter configurado"

# 6. NAVEGAR AL PROYECTO
cd "$(dirname "$0")"

# 7. INSTALAR DEPENDENCIAS DEL PROYECTO
show_progress "Instalando dependencias del proyecto"

# Limpiar cache
flutter clean

# Obtener dependencias
flutter pub get

# Generar código
flutter pub run build_runner build --delete-conflicting-outputs

show_success "Dependencias instaladas"

# 8. CONFIGURAR FIREBASE
echo ""
echo -e "${YELLOW}🔥 Firebase Configuration${NC}"
echo "================================"

# Verificar google-services.json
if [ -f "android/app/google-services.json" ]; then
    show_success "google-services.json encontrado"
else
    show_error "google-services.json no encontrado"
    echo "Coloca el archivo en: android/app/google-services.json"
fi

# Verificar GoogleService-Info.plist (iOS)
if [ -f "ios/Runner/GoogleService-Info.plist" ]; then
    show_success "GoogleService-Info.plist encontrado"
else
    echo -e "${YELLOW}⚠️  GoogleService-Info.plist no encontrado (necesario para iOS)${NC}"
fi

# 9. CREAR ARCHIVO DE VARIABLES DE ENTORNO
if [ ! -f ".env" ]; then
    show_progress "Creando archivo .env"
    cat > .env << EOL
# API Configuration
API_BASE_URL=https://www.enfocadosendiostv.com/api
API_VERSION=v1

# Firebase (actualiza con tus valores)
FIREBASE_API_KEY=AIzaSyDuHLg2TgJhb3FSNnIK2xau2RZYX_yz634
FIREBASE_PROJECT_ID=enfocados-en-dios-tv

# YouTube (necesitas obtener tu API key)
YOUTUBE_API_KEY=your_youtube_api_key
YOUTUBE_CHANNEL_ID=UCYourChannelId

# Analytics (opcional)
MIXPANEL_TOKEN=your_mixpanel_token
SENTRY_DSN=your_sentry_dsn
EOL
    show_success "Archivo .env creado (actualiza los valores necesarios)"
else
    show_success "Archivo .env ya existe"
fi

# 10. GENERAR KEYSTORE PARA ANDROID
echo ""
echo -e "${YELLOW}🔐 Keystore para Android${NC}"
echo "========================="

KEYSTORE_PATH="android/app/enfocadostv-release-key.jks"

if [ ! -f "$KEYSTORE_PATH" ]; then
    read -p "¿Deseas generar un keystore ahora? (s/n): " -n 1 -r
    echo ""

    if [[ $REPLY =~ ^[Ss]$ ]]; then
        show_progress "Generando keystore"

        # Solicitar información
        read -p "Contraseña para el keystore (mínimo 6 caracteres): " -s STORE_PASSWORD
        echo ""

        if [ ${#STORE_PASSWORD} -lt 6 ]; then
            show_error "La contraseña debe tener al menos 6 caracteres"
        else
            keytool -genkeypair \
                -v \
                -keystore "$KEYSTORE_PATH" \
                -alias enfocadostv \
                -keyalg RSA \
                -keysize 2048 \
                -validity 10000 \
                -storepass "$STORE_PASSWORD" \
                -keypass "$STORE_PASSWORD" \
                -dname "CN=Enfocados en Dios TV, OU=Desarrollo, O=Enfocados en Dios TV Ministry, L=Ciudad, ST=Estado, C=US"

            # Actualizar key.properties
            cat > android/key.properties << EOL
storePassword=$STORE_PASSWORD
keyPassword=$STORE_PASSWORD
keyAlias=enfocadostv
storeFile=../app/enfocadostv-release-key.jks
EOL

            show_success "Keystore generado"
            echo -e "${RED}⚠️  IMPORTANTE: Guarda el keystore en un lugar seguro${NC}"
        fi
    fi
else
    show_success "Keystore ya existe"
fi

# 11. RESUMEN FINAL
echo ""
echo "=============================================="
echo -e "${GREEN}🎉 Configuración Completada${NC}"
echo "=============================================="
echo ""
echo "✅ Flutter instalado y configurado"
echo "✅ Dependencias del proyecto instaladas"
echo "✅ Firebase configurado"
echo "✅ Variables de entorno creadas"

if [ -f "$KEYSTORE_PATH" ]; then
    echo "✅ Keystore para Android generado"
fi

echo ""
echo -e "${YELLOW}📋 Próximos pasos:${NC}"
echo "1. Actualiza los valores en .env con tus API keys"
echo "2. Para ejecutar la app en debug:"
echo "   flutter run"
echo ""
echo "3. Para compilar APK de producción:"
echo "   flutter build apk --release"
echo ""
echo "4. Para compilar App Bundle (Play Store):"
echo "   flutter build appbundle --release"
echo ""
echo "5. Para iOS (solo en macOS):"
echo "   flutter build ios --release"
echo ""
echo -e "${BLUE}📚 Documentación:${NC}"
echo "   README.md - Documentación completa del proyecto"
echo "   store/google_play/checklist.md - Checklist para Play Store"
echo "   store/app_store/checklist.md - Checklist para App Store"
echo ""
echo -e "${GREEN}¡Listo para desarrollar! 🚀${NC}"