#!/bin/bash

echo "🚀 Instalación de Flutter para Enfocados en Dios TV"
echo "===================================================="
echo ""

# Colores
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
NC='\033[0m'

# Detectar arquitectura del Mac
ARCH=$(uname -m)
echo "Arquitectura detectada: $ARCH"

# Verificar si Homebrew está instalado
if ! command -v brew &> /dev/null; then
    echo -e "${YELLOW}Homebrew no está instalado. Instalando...${NC}"
    /bin/bash -c "$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/HEAD/install.sh)"

    # Configurar PATH para Homebrew en Apple Silicon
    if [[ "$ARCH" == "arm64" ]]; then
        echo 'eval "$(/opt/homebrew/bin/brew shellenv)"' >> ~/.zprofile
        eval "$(/opt/homebrew/bin/brew shellenv)"
    fi
else
    echo -e "${GREEN}✅ Homebrew ya está instalado${NC}"
fi

# Instalar Flutter usando Homebrew
echo -e "${YELLOW}Instalando Flutter...${NC}"
brew install --cask flutter

# Verificar instalación
if flutter --version; then
    echo -e "${GREEN}✅ Flutter instalado correctamente${NC}"
else
    echo -e "${RED}❌ Error instalando Flutter${NC}"
    echo "Intentando instalación manual..."

    # Instalación manual como alternativa
    cd ~
    git clone https://github.com/flutter/flutter.git -b stable
    echo 'export PATH="$PATH:$HOME/flutter/bin"' >> ~/.zshrc
    source ~/.zshrc
fi

# Instalar herramientas de Android
echo -e "${YELLOW}Instalando herramientas de Android...${NC}"
brew install --cask android-commandlinetools

# Aceptar licencias de Android
flutter doctor --android-licenses

# Verificar estado completo
echo ""
echo -e "${GREEN}Estado de Flutter:${NC}"
flutter doctor

echo ""
echo -e "${GREEN}✅ Instalación completada${NC}"
echo ""
echo "Próximo paso: Ejecuta el siguiente comando para compilar la app:"
echo -e "${YELLOW}cd /Users/jeviwayeirl/Desktop/enfocadosendiostv.com/flutter_app${NC}"
echo -e "${YELLOW}./compile_app.sh${NC}"