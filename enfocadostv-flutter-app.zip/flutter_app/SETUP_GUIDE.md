# 🚀 GUÍA DE SETUP - ENFOCADOS EN DIOS TV APP

## 📋 Requisitos Previos

### Herramientas Necesarias
- Flutter SDK 3.16.0 o superior
- Dart SDK 3.0.0 o superior
- Android Studio / Xcode
- Visual Studio Code o Android Studio IDE
- Git
- Node.js 18+ (para el backend)

### Verificar Instalación
```bash
# Verificar Flutter
flutter --version

# Verificar que todo esté configurado
flutter doctor

# Debe mostrar checkmarks en:
# ✓ Flutter
# ✓ Android toolchain
# ✓ Xcode (solo macOS)
# ✓ Chrome (opcional)
# ✓ Android Studio
# ✓ VS Code (opcional)
```

---

## 🎯 PASO 1: Crear el Proyecto

```bash
# Crear proyecto con nombre de organización
flutter create --org com.enfocadosendiostv --project-name enfocados_tv_app enfocados_tv_app

# Entrar al directorio
cd enfocados_tv_app

# Abrir en VS Code
code .
```

---

## 📦 PASO 2: Configurar Dependencias

### Reemplazar pubspec.yaml

```yaml
name: enfocados_tv_app
description: Enfocados en Dios TV - Biblia & Academia
publish_to: 'none'
version: 1.0.0+1

environment:
  sdk: '>=3.0.0 <4.0.0'

dependencies:
  flutter:
    sdk: flutter
  flutter_localizations:
    sdk: flutter

  # Iconos
  cupertino_icons: ^1.0.6

  # State Management
  flutter_riverpod: ^2.4.9
  riverpod_annotation: ^2.3.3

  # Navegación
  auto_route: ^7.8.4

  # Red y API
  dio: ^5.4.0
  retrofit: ^4.0.3
  pretty_dio_logger: ^1.3.1

  # Almacenamiento
  flutter_secure_storage: ^9.0.0
  shared_preferences: ^2.2.2
  hive_flutter: ^1.1.0
  path_provider: ^2.1.1

  # Base de datos local
  sqflite: ^2.3.0

  # UI y Componentes
  flutter_svg: ^2.0.9
  cached_network_image: ^3.3.0
  shimmer: ^3.0.0
  lottie: ^2.7.0
  flutter_animate: ^4.3.0

  # Video
  video_player: ^2.8.1
  youtube_player_flutter: ^8.1.2

  # Utilidades
  intl: ^0.18.1
  equatable: ^2.0.5
  json_annotation: ^4.8.1
  freezed_annotation: ^2.4.1

  # Compartir y Enlaces
  share_plus: ^7.2.1
  url_launcher: ^6.2.2

  # Firebase
  firebase_core: ^2.24.2
  firebase_messaging: ^14.7.9
  firebase_analytics: ^10.8.0
  firebase_crashlytics: ^3.4.8

  # Permisos y Dispositivo
  permission_handler: ^11.1.0
  device_info_plus: ^9.1.1
  connectivity_plus: ^5.0.2

  # Otros
  flutter_dotenv: ^5.1.0
  logger: ^2.0.2

dev_dependencies:
  flutter_test:
    sdk: flutter

  # Linting
  flutter_lints: ^3.0.1

  # Code Generation
  build_runner: ^2.4.7
  auto_route_generator: ^7.3.2
  json_serializable: ^6.7.1
  retrofit_generator: ^8.0.6
  riverpod_generator: ^2.3.9
  freezed: ^2.4.6

  # Testing
  mockito: ^5.4.4
  bloc_test: ^9.1.5

# Assets
flutter:
  uses-material-design: true

  assets:
    - assets/images/
    - assets/images/icons/
    - assets/animations/
    - assets/fonts/
    - .env
    - .env.production

  fonts:
    - family: Montserrat
      fonts:
        - asset: assets/fonts/Montserrat-Regular.ttf
          weight: 400
        - asset: assets/fonts/Montserrat-Medium.ttf
          weight: 500
        - asset: assets/fonts/Montserrat-SemiBold.ttf
          weight: 600
        - asset: assets/fonts/Montserrat-Bold.ttf
          weight: 700
        - asset: assets/fonts/Montserrat-Black.ttf
          weight: 900

    - family: HebrewFont
      fonts:
        - asset: assets/fonts/NotoSansHebrew-Regular.ttf

    - family: GreekFont
      fonts:
        - asset: assets/fonts/NotoSansGreek-Regular.ttf
```

### Instalar Dependencias
```bash
# Obtener todas las dependencias
flutter pub get

# Ejecutar generadores de código
flutter pub run build_runner build --delete-conflicting-outputs
```

---

## 🔧 PASO 3: Configuración de Plataformas

### Android Configuration

#### android/app/build.gradle
```gradle
android {
    compileSdkVersion 34
    ndkVersion flutter.ndkVersion

    defaultConfig {
        applicationId "com.enfocadosendiostv.app"
        minSdkVersion 21
        targetSdkVersion 34
        versionCode flutterVersionCode.toInteger()
        versionName flutterVersionName
        multiDexEnabled true
    }

    buildTypes {
        release {
            signingConfig signingConfigs.release
            minifyEnabled true
            proguardFiles getDefaultProguardFile('proguard-android.txt'), 'proguard-rules.pro'
        }
    }
}

dependencies {
    implementation 'com.android.support:multidex:2.0.1'
}
```

#### android/app/src/main/AndroidManifest.xml
```xml
<manifest xmlns:android="http://schemas.android.com/apk/res/android">

    <!-- Permisos -->
    <uses-permission android:name="android.permission.INTERNET"/>
    <uses-permission android:name="android.permission.ACCESS_NETWORK_STATE"/>
    <uses-permission android:name="android.permission.WAKE_LOCK"/>
    <uses-permission android:name="android.permission.VIBRATE"/>
    <uses-permission android:name="android.permission.RECEIVE_BOOT_COMPLETED"/>

    <application
        android:label="Enfocados en Dios TV"
        android:name="${applicationName}"
        android:icon="@mipmap/ic_launcher"
        android:usesCleartextTraffic="false"
        android:requestLegacyExternalStorage="true">

        <activity
            android:name=".MainActivity"
            android:exported="true"
            android:launchMode="singleTop"
            android:theme="@style/LaunchTheme"
            android:configChanges="orientation|keyboardHidden|keyboard|screenSize|smallestScreenSize|locale|layoutDirection|fontScale|screenLayout|density|uiMode"
            android:hardwareAccelerated="true"
            android:windowSoftInputMode="adjustResize">

            <meta-data
                android:name="io.flutter.embedding.android.NormalTheme"
                android:resource="@style/NormalTheme"/>

            <intent-filter>
                <action android:name="android.intent.action.MAIN"/>
                <category android:name="android.intent.category.LAUNCHER"/>
            </intent-filter>
        </activity>

        <!-- Firebase Cloud Messaging -->
        <meta-data
            android:name="com.google.firebase.messaging.default_notification_channel_id"
            android:value="enfocados_tv_channel"/>

        <meta-data
            android:name="flutterEmbedding"
            android:value="2"/>
    </application>

    <!-- Queries para url_launcher -->
    <queries>
        <intent>
            <action android:name="android.intent.action.VIEW"/>
            <data android:scheme="https"/>
        </intent>
    </queries>
</manifest>
```

### iOS Configuration

#### ios/Runner/Info.plist
```xml
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
    <key>CFBundleDevelopmentRegion</key>
    <string>$(DEVELOPMENT_LANGUAGE)</string>
    <key>CFBundleDisplayName</key>
    <string>Enfocados TV</string>
    <key>CFBundleExecutable</key>
    <string>$(EXECUTABLE_NAME)</string>
    <key>CFBundleIdentifier</key>
    <string>$(PRODUCT_BUNDLE_IDENTIFIER)</string>
    <key>CFBundleName</key>
    <string>enfocados_tv_app</string>
    <key>CFBundlePackageType</key>
    <string>APPL</string>
    <key>CFBundleShortVersionString</key>
    <string>$(FLUTTER_BUILD_NAME)</string>
    <key>CFBundleSignature</key>
    <string>????</string>
    <key>CFBundleVersion</key>
    <string>$(FLUTTER_BUILD_NUMBER)</string>
    <key>LSRequiresIPhoneOS</key>
    <true/>

    <!-- Permisos -->
    <key>NSCameraUsageDescription</key>
    <string>Esta app necesita acceso a la cámara para tomar fotos de perfil</string>
    <key>NSPhotoLibraryUsageDescription</key>
    <string>Esta app necesita acceso a tus fotos para seleccionar imagen de perfil</string>
    <key>NSMicrophoneUsageDescription</key>
    <string>Esta app necesita acceso al micrófono para grabar notas de audio</string>

    <!-- Orientación -->
    <key>UISupportedInterfaceOrientations</key>
    <array>
        <string>UIInterfaceOrientationPortrait</string>
    </array>

    <!-- App Transport Security -->
    <key>NSAppTransportSecurity</key>
    <dict>
        <key>NSAllowsArbitraryLoads</key>
        <false/>
        <key>NSExceptionDomains</key>
        <dict>
            <key>enfocadosendiostv.com</key>
            <dict>
                <key>NSIncludesSubdomains</key>
                <true/>
                <key>NSTemporaryExceptionAllowsInsecureHTTPLoads</key>
                <false/>
            </dict>
        </dict>
    </dict>

    <!-- URL Schemes -->
    <key>LSApplicationQueriesSchemes</key>
    <array>
        <string>https</string>
        <string>http</string>
        <string>whatsapp</string>
        <string>youtube</string>
        <string>fb</string>
        <string>instagram</string>
    </array>
</dict>
</plist>
```

---

## 🌐 PASO 4: Variables de Entorno

### Crear archivo .env
```env
# API Configuration
API_BASE_URL=https://www.enfocadosendiostv.com/api/mobile
API_TIMEOUT=30000

# Firebase
FIREBASE_API_KEY=your_firebase_api_key
FIREBASE_AUTH_DOMAIN=enfocados-tv.firebaseapp.com
FIREBASE_PROJECT_ID=enfocados-tv
FIREBASE_STORAGE_BUCKET=enfocados-tv.appspot.com
FIREBASE_MESSAGING_SENDER_ID=your_sender_id
FIREBASE_APP_ID=your_app_id

# YouTube API
YOUTUBE_API_KEY=your_youtube_api_key
YOUTUBE_CHANNEL_ID=UC_your_channel_id

# Sentry (Error Tracking)
SENTRY_DSN=your_sentry_dsn

# App Configuration
APP_NAME="Enfocados en Dios TV"
APP_VERSION=1.0.0
APP_BUILD_NUMBER=1

# Feature Flags
ENABLE_OFFLINE_MODE=true
ENABLE_ANALYTICS=true
ENABLE_CRASH_REPORTING=true
```

### Crear archivo .env.production
```env
# Production API
API_BASE_URL=https://api.enfocadosendiostv.com/v1
API_TIMEOUT=30000

# Production Firebase
FIREBASE_API_KEY=production_firebase_key
# ... resto de configuración de producción
```

---

## 🎨 PASO 5: Agregar Assets

### Estructura de carpetas de assets
```bash
mkdir -p assets/images/icons
mkdir -p assets/animations
mkdir -p assets/fonts

# Descargar fuentes Montserrat
# https://fonts.google.com/specimen/Montserrat

# Descargar animaciones Lottie (opcional)
# https://lottiefiles.com/
```

### Crear archivos de assets básicos

#### assets/images/logo.png
- Logo de Enfocados en Dios TV
- Tamaño recomendado: 512x512px
- Formato: PNG con transparencia

#### assets/images/splash.png
- Imagen para splash screen
- Tamaño: 1920x1920px (será redimensionada)
- Formato: PNG

#### assets/animations/loading.json
- Animación Lottie para carga
- Descarga desde LottieFiles

---

## 🔥 PASO 6: Configurar Firebase

### 1. Crear proyecto en Firebase Console
```
1. Ir a https://console.firebase.google.com
2. Crear nuevo proyecto: "enfocados-tv"
3. Habilitar Google Analytics
```

### 2. Agregar app Android
```
1. Package name: com.enfocadosendiostv.app
2. Descargar google-services.json
3. Colocar en android/app/
```

### 3. Agregar app iOS
```
1. Bundle ID: com.enfocadosendiostv.app
2. Descargar GoogleService-Info.plist
3. Colocar en ios/Runner/
```

### 4. Inicializar Firebase en Flutter
```bash
# Instalar Firebase CLI
npm install -g firebase-tools

# Login
firebase login

# Configurar FlutterFire
flutter pub global activate flutterfire_cli

# Configurar proyecto
flutterfire configure
```

---

## 📱 PASO 7: Ejecutar la App

### Desarrollo
```bash
# Verificar dispositivos conectados
flutter devices

# Ejecutar en modo debug
flutter run

# Ejecutar con hot reload
flutter run --hot

# Ejecutar en dispositivo específico
flutter run -d device_id
```

### Build para Testing
```bash
# Android APK
flutter build apk --debug

# iOS
flutter build ios --debug --no-codesign
```

---

## 🧪 PASO 8: Testing

### Ejecutar tests
```bash
# Todos los tests
flutter test

# Con coverage
flutter test --coverage

# Test específico
flutter test test/unit/auth_test.dart
```

---

## 🚀 PASO 9: Build de Producción

### Android
```bash
# Generar keystore
keytool -genkey -v -keystore ~/enfocados-key.jks -keyalg RSA -keysize 2048 -validity 10000 -alias enfocados

# Configurar key.properties en android/
storePassword=your_store_password
keyPassword=your_key_password
keyAlias=enfocados
storeFile=/Users/your_user/enfocados-key.jks

# Build APK
flutter build apk --release --obfuscate --split-debug-info=debug-info

# Build App Bundle
flutter build appbundle --release --obfuscate --split-debug-info=debug-info
```

### iOS
```bash
# Abrir en Xcode
open ios/Runner.xcworkspace

# Configurar signing & capabilities

# Build
flutter build ios --release --obfuscate --split-debug-info=debug-info

# Archive para App Store
flutter build ipa
```

---

## 📊 PASO 10: Monitoreo y Analytics

### Configurar Sentry
```dart
// main.dart
import 'package:sentry_flutter/sentry_flutter.dart';

Future<void> main() async {
  await SentryFlutter.init(
    (options) {
      options.dsn = 'YOUR_SENTRY_DSN';
      options.tracesSampleRate = 1.0;
      options.environment = 'production';
    },
    appRunner: () => runApp(MyApp()),
  );
}
```

---

## 🐛 Troubleshooting Común

### Error: Flutter Doctor Issues
```bash
# Android licenses
flutter doctor --android-licenses

# Reinstalar Flutter
flutter clean
flutter pub get
```

### Error: CocoaPods (iOS)
```bash
cd ios
pod install --repo-update
cd ..
```

### Error: Build Cache
```bash
flutter clean
flutter pub get
cd ios && pod install && cd ..
flutter run
```

---

## 📚 Recursos Adicionales

- [Flutter Documentation](https://docs.flutter.dev)
- [Riverpod Documentation](https://riverpod.dev)
- [Firebase Flutter](https://firebase.flutter.dev)
- [Material Design 3](https://m3.material.io)

---

## 👥 Soporte

Para soporte técnico:
- Email: desarrollo@enfocadosendiostv.com
- GitHub: github.com/enfocadosendiostv/app

---

**Última actualización:** Diciembre 2024
**Versión del documento:** 1.0