#!/bin/bash

clear

echo "╔════════════════════════════════════════════════════════╗"
echo "║                                                        ║"
echo "║    🙏 ENFOCADOS EN DIOS TV - MOBILE APP 🙏            ║"
echo "║                                                        ║"
echo "║         Configuración y Compilación Automática        ║"
echo "║                                                        ║"
echo "╚════════════════════════════════════════════════════════╝"
echo ""

# Colores
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
BLUE='\033[0;34m'
NC='\033[0m'

# Cambiar al directorio del proyecto
cd /Users/jeviwayeirl/Desktop/enfocadosendiostv.com/flutter_app

echo -e "${BLUE}📍 Directorio del proyecto:${NC}"
pwd
echo ""

# Función para pausar
pause() {
    echo ""
    read -p "Presiona ENTER para continuar..."
    clear
}

# PASO 1: Verificar Flutter
echo -e "${YELLOW}PASO 1: Verificando Flutter${NC}"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━"

if command -v flutter &> /dev/null; then
    echo -e "${GREEN}✅ Flutter está instalado${NC}"
    flutter --version
else
    echo -e "${RED}❌ Flutter NO está instalado${NC}"
    echo ""
    echo "Instalando Flutter automáticamente..."
    chmod +x install_flutter.sh
    ./install_flutter.sh

    # Verificar de nuevo
    if command -v flutter &> /dev/null; then
        echo -e "${GREEN}✅ Flutter instalado correctamente${NC}"
    else
        echo -e "${RED}Flutter no se pudo instalar automáticamente${NC}"
        echo "Por favor, instala Flutter manualmente desde: https://flutter.dev"
        exit 1
    fi
fi

pause

# PASO 2: Verificar Firebase
echo -e "${YELLOW}PASO 2: Verificando Firebase${NC}"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━"

if [ -f "android/app/google-services.json" ]; then
    echo -e "${GREEN}✅ google-services.json encontrado${NC}"
else
    echo -e "${RED}❌ google-services.json NO encontrado${NC}"
    echo "Buscando en Downloads..."
    if [ -f "/Users/jeviwayeirl/Downloads/google-services.json" ]; then
        cp /Users/jeviwayeirl/Downloads/google-services.json android/app/
        echo -e "${GREEN}✅ Archivo copiado desde Downloads${NC}"
    fi
fi

pause

# PASO 3: Generar Keystore
echo -e "${YELLOW}PASO 3: Keystore para firma${NC}"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━"

if [ -f "android/app/enfocadostv-release-key.jks" ]; then
    echo -e "${GREEN}✅ Keystore ya existe${NC}"
else
    echo -e "${YELLOW}Necesitas un keystore para firmar la app${NC}"
    read -p "¿Quieres crear uno ahora? (s/n): " -n 1 -r
    echo
    if [[ $REPLY =~ ^[Ss]$ ]]; then
        chmod +x create_keystore.sh
        ./create_keystore.sh
    fi
fi

pause

# PASO 4: Menú principal
while true; do
    clear
    echo "╔════════════════════════════════════════════════════════╗"
    echo "║          MENÚ PRINCIPAL - ENFOCADOS EN DIOS TV        ║"
    echo "╚════════════════════════════════════════════════════════╝"
    echo ""
    echo "Selecciona una opción:"
    echo ""
    echo "  1️⃣  Compilar APK de PRUEBA (Debug)"
    echo "      → Rápido, para probar en tu teléfono"
    echo ""
    echo "  2️⃣  Compilar APK de PRODUCCIÓN (Release)"
    echo "      → Optimizado y firmado para distribución"
    echo ""
    echo "  3️⃣  Compilar para GOOGLE PLAY STORE"
    echo "      → Genera .AAB para subir a la tienda"
    echo ""
    echo "  4️⃣  Ver instrucciones de publicación"
    echo ""
    echo "  5️⃣  Ejecutar app en modo desarrollo"
    echo ""
    echo "  6️⃣  Limpiar proyecto"
    echo ""
    echo "  0️⃣  Salir"
    echo ""
    read -p "Opción: " choice

    case $choice in
        1)
            clear
            echo -e "${YELLOW}Compilando APK de Debug...${NC}"
            chmod +x compile_app.sh
            echo "1" | ./compile_app.sh
            pause
            ;;

        2)
            clear
            echo -e "${YELLOW}Compilando APK de Release...${NC}"
            chmod +x compile_app.sh
            echo "3" | ./compile_app.sh
            pause
            ;;

        3)
            clear
            echo -e "${YELLOW}Compilando para Play Store...${NC}"
            chmod +x compile_app.sh
            echo "4" | ./compile_app.sh
            pause
            ;;

        4)
            clear
            echo -e "${BLUE}📱 INSTRUCCIONES PARA PUBLICAR EN PLAY STORE${NC}"
            echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
            echo ""
            echo "1. Crea cuenta en: https://play.google.com/console ($25 USD)"
            echo "2. Crea nueva aplicación"
            echo "3. Completa información:"
            echo "   • Nombre: Enfocados en Dios TV"
            echo "   • Descripción (ver store/google_play/store_listing.md)"
            echo "   • Capturas de pantalla (mínimo 2)"
            echo "   • Ícono 512x512"
            echo "4. Sube el archivo .aab desde:"
            echo "   build/app/outputs/bundle/release/app-release.aab"
            echo "5. Envía para revisión"
            echo ""
            echo "Tiempo estimado: 2-24 horas para aprobación"
            pause
            ;;

        5)
            clear
            echo -e "${YELLOW}Ejecutando app en modo desarrollo...${NC}"
            echo "Conecta tu teléfono o inicia un emulador"
            flutter run
            pause
            ;;

        6)
            clear
            echo -e "${YELLOW}Limpiando proyecto...${NC}"
            flutter clean
            rm -rf build/
            echo -e "${GREEN}✅ Proyecto limpio${NC}"
            pause
            ;;

        0)
            echo ""
            echo -e "${GREEN}¡Gracias por usar Enfocados en Dios TV!${NC}"
            echo "Que Dios bendiga tu ministerio 🙏"
            exit 0
            ;;

        *)
            echo -e "${RED}Opción no válida${NC}"
            sleep 2
            ;;
    esac
done