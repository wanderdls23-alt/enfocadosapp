# 🍎 App Store - Información de la Tienda

## Información Básica

### Nombre de la App
**Primario:** Enfocados en Dios TV
**Subtítulo:** Biblia, Videos y Academia

### Información de la App

#### Descripción (4000 caracteres)

```
Enfocados en Dios TV es tu compañero espiritual diario, diseñado para fortalecer tu fe y profundizar tu relación con Dios a través de recursos bíblicos completos, contenido multimedia inspirador y una comunidad cristiana vibrante.

BIBLIA COMPLETA CON CONCORDANCIA STRONG
• Accede a la Biblia Reina Valera 1960 completa con concordancia Strong integrada
• Explora versículos paralelos y referencias cruzadas para un estudio más profundo
• Búsqueda avanzada por palabras, temas y referencias bíblicas
• Crea marcadores y notas personales para tu estudio
• Lectura offline para estudiar en cualquier momento
• Planes de lectura personalizados que se adaptan a tu ritmo

CONTENIDO MULTIMEDIA CRISTIANO
• Disfruta predicaciones en vivo y grabadas de nuestro ministerio
• Series completas de estudios bíblicos temáticos
• Testimonios inspiradores de la comunidad
• Contenido exclusivo de nuestro canal de YouTube
• Descarga videos para verlos sin conexión
• Calidad HD optimizada para tu dispositivo

ACADEMIA BÍBLICA INTEGRAL
• Cursos estructurados desde nivel básico hasta avanzado
• Lecciones interactivas con evaluaciones de progreso
• Certificados oficiales al completar cada curso
• Material de estudio descargable en PDF
• Seguimiento sincronizado entre dispositivos
• Nuevos cursos añadidos regularmente

VERSÍCULO DIARIO PERSONALIZADO
• Inteligencia artificial que aprende de tus hábitos de lectura
• Versículos seleccionados específicamente para ti
• Notificaciones diarias en el horario que prefieras
• Comparte versículos con diseños hermosos en redes sociales
• Reflexiones y devocionales diarios
• Historial de versículos anteriores

COMUNIDAD DE FE ACTIVA
• Muro de oración interactivo donde puedes compartir y orar por otros
• Comparte testimonios que edifiquen a la comunidad
• Calendario de eventos y actividades de la iglesia
• Grupos de estudio bíblico por temas
• Chat con hermanos en la fe

CARACTERÍSTICAS ADICIONALES
• Transmisiones en vivo de servicios y eventos especiales
• Sistema seguro de donaciones y diezmos
• Modo oscuro para lectura nocturna cómoda
• Sincronización automática entre todos tus dispositivos
• Notificaciones personalizables para recordatorios de oración
• Soporte en español e inglés

PRIVACIDAD Y SEGURIDAD
Respetamos tu privacidad. Tus datos personales están protegidos y nunca se comparten con terceros sin tu consentimiento. Toda la información de donaciones se procesa de forma segura mediante encriptación de grado bancario.

SIEMPRE MEJORANDO
Actualizamos regularmente la aplicación con nuevas características, mejoras de rendimiento y contenido fresco. Tu feedback es importante para nosotros.

Únete a miles de creyentes que están fortaleciendo su fe diariamente. Descarga Enfocados en Dios TV hoy y comienza tu viaje espiritual con nosotros.

Para soporte y sugerencias: soporte@enfocadosendiostv.com
Visita nuestra web: www.enfocadosendiostv.com
```

#### Palabras Clave
```
biblia,cristiano,dios,jesus,versiculo,oracion,fe,iglesia,devocional,evangelio,estudio biblico,predicacion,ministerio,espiritual
```

#### URL de Soporte
https://www.enfocadosendiostv.com/support

#### URL de Marketing
https://www.enfocadosendiostv.com

## Categorización

### Categoría Principal
Libros

### Categoría Secundaria
Educación

## Clasificación por Edad
4+

## Información de Privacidad

### Política de Privacidad
https://www.enfocadosendiostv.com/privacy

### Prácticas de Privacidad (Datos recopilados)

#### Datos vinculados al usuario:
- Información de contacto (email, nombre)
- Identificadores de usuario
- Datos de uso
- Diagnósticos

#### Datos no vinculados al usuario:
- Datos de análisis agregados
- Datos de rendimiento

### Propósitos de recopilación:
- Funcionalidad de la app
- Análisis
- Mejora del producto
- Comunicaciones con el usuario

## Capturas de Pantalla

### iPhone 6.7" (iPhone 15 Pro Max) - Requeridas
1. `iphone67_1_home.png` - Pantalla principal
2. `iphone67_2_bible.png` - Lectura bíblica
3. `iphone67_3_videos.png` - Catálogo de videos
4. `iphone67_4_academy.png` - Academia
5. `iphone67_5_prayer.png` - Muro de oración

### iPhone 6.5" (iPhone 14 Plus) - Requeridas
1. `iphone65_1_home.png`
2. `iphone65_2_bible.png`
3. `iphone65_3_videos.png`
4. `iphone65_4_academy.png`
5. `iphone65_5_prayer.png`

### iPhone 5.5" (iPhone 8 Plus) - Opcionales
1. `iphone55_1_home.png`
2. `iphone55_2_bible.png`

### iPad Pro 12.9" - Requeridas
1. `ipad129_1_split.png` - Vista dividida
2. `ipad129_2_bible.png` - Biblia en iPad

### iPad Pro 11" - Opcionales
1. `ipad11_1_home.png`
2. `ipad11_2_academy.png`

## Información de Contacto

### Información del desarrollador
- **Nombre:** Enfocados en Dios TV Ministry
- **Dirección:** [Dirección completa]
- **Teléfono:** [Número de teléfono]
- **Email:** info@enfocadosendiostv.com

### Información de soporte
- **Email:** soporte@enfocadosendiostv.com
- **Teléfono:** [Número de soporte]

## Pricing y Disponibilidad

### Precio
Gratis

### Compras dentro de la app
- Donación $5 USD
- Donación $10 USD
- Donación $25 USD
- Donación $50 USD
- Donación $100 USD
- Donación personalizada

### Disponibilidad
- Todos los territorios donde Apple distribuye apps

### Fecha de lanzamiento
[A determinar]

## Notas de la Versión

### Versión 1.0.0
Lanzamiento inicial con todas las características principales:
• Biblia completa con concordancia Strong
• Catálogo de videos cristianos
• Academia bíblica con cursos
• Versículo diario personalizado
• Muro de oración comunitario
• Sistema de donaciones
• Y mucho más!

## Review Information

### Notas para el revisor
```
Enfocados en Dios TV es una aplicación cristiana completa que ofrece recursos bíblicos, contenido multimedia y herramientas de estudio.

Cuenta de prueba (si es necesaria):
Email: demo@enfocadosendiostv.com
Password: Demo2024!

La aplicación requiere registro para acceder a características personalizadas como guardado de progreso y notas personales. El contenido básico está disponible sin registro.

Todas las donaciones son opcionales y procesadas de forma segura a través de sistemas de pago certificados.

El contenido de video proviene de nuestro canal oficial de YouTube y servidores propios con todos los derechos correspondientes.
```

### Información de contacto del revisor
- Nombre: [Nombre del contacto]
- Email: [Email del contacto]
- Teléfono: [Teléfono del contacto]

### Demo Account
- Email: demo@enfocadosendiostv.com
- Password: Demo2024!

## App Previews (Videos Opcionales)

### Especificaciones
- Formato: H.264, AAC
- Resolución: 1920x886 (iPhone), 1200x1600 (iPad)
- Duración: 15-30 segundos
- FPS: 30
- Tamaño máximo: 500MB

### Guión sugerido
1. Logo animado (2s)
2. Lectura bíblica con Strong (5s)
3. Videos y predicaciones (5s)
4. Academia y cursos (5s)
5. Comunidad y oración (5s)
6. Call to action (3s)

## Requisitos Técnicos

### Versión mínima de iOS
iOS 12.0

### Dispositivos compatibles
- iPhone (requiere iOS 12.0 o posterior)
- iPad (requiere iPadOS 12.0 o posterior)
- iPod touch (requiere iOS 12.0 o posterior)

### Idiomas
- Español (Principal)
- Inglés

### Tamaño de la app
~95 MB (puede variar por dispositivo)

## TestFlight

### Beta Testing Information
- Descripción beta: "Ayúdanos a mejorar Enfocados en Dios TV probando nuevas características antes del lanzamiento oficial."
- Email de feedback beta: beta@enfocadosendiostv.com
- Límite de testers: 10,000

## Notas Adicionales

### Cumplimiento
- [x] Cumple con las Guidelines de la App Store
- [x] No contiene contenido objetable
- [x] Respeta derechos de autor
- [x] Implementa Sign in with Apple (si tiene login social)
- [x] Cumple con políticas de privacidad infantil
- [x] No usa APIs privadas

### Preparación para el lanzamiento
1. Completar todos los metadatos en App Store Connect
2. Subir build mediante Xcode o Transporter
3. Configurar disponibilidad y precios
4. Enviar para revisión
5. Responder rápidamente a cualquier feedback del equipo de revisión