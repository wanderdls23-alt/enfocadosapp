# 🍎 App Store - Checklist de Publicación

## ✅ Pre-requisitos

### Cuenta de Desarrollador
- [ ] Apple Developer Program activo ($99 USD/año)
- [ ] Acuerdo de desarrollador aceptado y actualizado
- [ ] Información fiscal completada (W-8/W-9)
- [ ] Información bancaria configurada
- [ ] Verificación de identidad completada

### Certificados y Provisioning
- [ ] Certificado de desarrollo iOS creado
- [ ] Certificado de distribución iOS creado
- [ ] App ID registrado en developer.apple.com
- [ ] Provisioning Profile de desarrollo
- [ ] Provisioning Profile de distribución (App Store)
- [ ] Push Notification Certificate (si usa notificaciones)

## 🔧 Configuración Técnica

### Xcode Setup
- [ ] Xcode actualizado a la última versión
- [ ] Command Line Tools instalados
- [ ] Simuladores iOS descargados
- [ ] Team configurado en Signing & Capabilities
- [ ] Bundle Identifier único configurado
- [ ] Capabilities habilitadas (Push, Background, etc.)

### Info.plist
- [x] Descripciones de uso de permisos (cámara, fotos, etc.)
- [x] Configuración de orientación
- [x] URL Schemes configurados
- [x] Idiomas soportados
- [ ] ITSAppUsesNonExemptEncryption configurado

### Build Settings
- [ ] Arquitecturas correctas (arm64)
- [ ] Bitcode deshabilitado (Flutter no lo soporta)
- [ ] Strip Swift Symbols habilitado
- [ ] Optimización de Release configurada
- [ ] dSYM files generados para Crashlytics

## 📸 Recursos Gráficos

### App Icons
- [ ] Icon-1024x1024 (App Store)
- [ ] Todos los tamaños de iconos en Assets.xcassets
- [ ] Sin transparencia ni canales alfa
- [ ] Sin esquinas redondeadas (iOS las aplica)

### Screenshots (Requeridos)
- [ ] iPhone 6.7" (1290 × 2796) - Mínimo 2
- [ ] iPhone 6.5" (1284 × 2778 o 1242 × 2688) - Mínimo 2
- [ ] iPad Pro 12.9" (2048 × 2732) - Mínimo 2

### Screenshots (Opcionales)
- [ ] iPhone 5.5" (1242 × 2208)
- [ ] iPad Pro 11" (1668 × 2388)
- [ ] Apple Watch (si aplica)

### App Preview (Opcional)
- [ ] Video de 15-30 segundos
- [ ] Formato correcto (H.264)
- [ ] Sin barras negras
- [ ] Audio AAC

## 📝 App Store Connect

### Información General
- [x] Nombre de la app (máx 30 caracteres)
- [x] Subtítulo (máx 30 caracteres)
- [x] Categoría principal
- [x] Categoría secundaria
- [x] Clasificación por edad
- [ ] Copyright
- [ ] Información de contacto

### Localización
- [x] Descripción en español (4000 caracteres)
- [ ] Descripción en inglés
- [x] Palabras clave (100 caracteres)
- [x] URL de soporte
- [x] URL de marketing
- [x] Notas de la versión

### Privacidad
- [x] URL de política de privacidad
- [x] Prácticas de privacidad configuradas
- [ ] Datos recopilados declarados
- [ ] Propósitos de uso especificados
- [ ] Identificadores de seguimiento declarados

### Pricing
- [x] Precio configurado (Gratis)
- [x] In-App Purchases configurados (si aplica)
- [ ] Acuerdos de compras completados
- [ ] Información fiscal de IAP

## 🧪 Testing

### Testing Local
- [ ] Build de debug funcional
- [ ] Build de release funcional
- [ ] Pruebas en dispositivo físico
- [ ] Pruebas en diferentes versiones de iOS
- [ ] Pruebas en iPhone y iPad

### TestFlight
- [ ] Build subido a TestFlight
- [ ] Información de beta testing
- [ ] Testers internos añadidos
- [ ] Testers externos (opcional)
- [ ] Feedback recopilado y aplicado

### Pruebas Críticas
- [ ] Instalación limpia
- [ ] Actualización desde versión anterior
- [ ] Login/Registro
- [ ] Compras in-app
- [ ] Notificaciones push
- [ ] Funcionalidad offline
- [ ] Deep links
- [ ] Crashlytics funcionando

## 📤 Proceso de Envío

### Preparación del Build
1. [ ] Incrementar version y build number
2. [ ] Archive desde Xcode (Product > Archive)
3. [ ] Validate archive
4. [ ] Upload a App Store Connect
5. [ ] Esperar procesamiento (15-60 min)

### App Store Connect
1. [ ] Seleccionar build procesado
2. [ ] Completar toda la información requerida
3. [ ] Añadir screenshots
4. [ ] Configurar fechas de lanzamiento
5. [ ] Review information completada
6. [ ] Submit for Review

### Review Information
- [ ] Notas para el revisor
- [ ] Cuenta demo (si requiere login)
- [ ] Información de contacto
- [ ] Attachments si son necesarios

## ⚠️ Problemas Comunes de Rechazo

### Diseño y Funcionalidad
- [ ] Crashes o bugs críticos
- [ ] Funcionalidad incompleta
- [ ] Links rotos o contenido faltante
- [ ] Performance pobre
- [ ] UI no optimizada para iOS

### Contenido
- [ ] Contenido inapropiado
- [ ] Violación de copyright
- [ ] Información engañosa
- [ ] Spam o contenido duplicado

### Técnico
- [ ] Uso de APIs privadas
- [ ] No implementar Sign in with Apple
- [ ] Permisos no justificados
- [ ] No seguir Human Interface Guidelines
- [ ] IPv6 no soportado

### Legal
- [ ] Política de privacidad faltante o inadecuada
- [ ] Términos de servicio faltantes
- [ ] Violación de guidelines de contenido
- [ ] Problemas de propiedad intelectual

## 📊 Post-Lanzamiento

### Monitoreo
- [ ] App Analytics configurado
- [ ] Crash reports monitoreados
- [ ] Reviews y ratings
- [ ] Ventas y tendencias

### Mantenimiento
- [ ] Responder reviews (App Store Connect)
- [ ] Actualizaciones regulares
- [ ] Bug fixes rápidos
- [ ] Comunicación con usuarios

### Marketing
- [ ] App Store Optimization (ASO)
- [ ] Apple Search Ads (opcional)
- [ ] Featuring request
- [ ] Social media announcement

## 🛠 Comandos Útiles

```bash
# Build para iOS
./scripts/build_ios.sh

# Limpiar build
flutter clean
cd ios && pod cache clean --all && cd ..

# Instalar pods
cd ios && pod install --repo-update && cd ..

# Abrir en Xcode
open ios/Runner.xcworkspace

# Ver dispositivos disponibles
xcrun simctl list devices

# Ejecutar en simulador específico
flutter run -d "iPhone 15 Pro"

# Build release
flutter build ios --release

# Upload a TestFlight
xcrun altool --upload-app -f path/to/app.ipa -u APPLE_ID -p APP_PASSWORD
```

## 🔗 Enlaces Importantes

- [App Store Connect](https://appstoreconnect.apple.com)
- [Apple Developer](https://developer.apple.com)
- [App Store Review Guidelines](https://developer.apple.com/app-store/review/guidelines/)
- [Human Interface Guidelines](https://developer.apple.com/design/human-interface-guidelines/)
- [TestFlight](https://testflight.apple.com)
- [App Store Connect Help](https://help.apple.com/app-store-connect/)

## 📅 Tiempos Estimados

- **Primera revisión:** 24-48 horas (puede ser hasta 7 días)
- **Actualizaciones:** 24 horas típicamente
- **Revisión expedita:** 24 horas (casos especiales)
- **Apelación de rechazo:** 24-48 horas

## 💡 Tips para Aprobación Rápida

1. **Sé transparente** con el uso de datos
2. **Justifica** todos los permisos solicitados
3. **Proporciona** cuenta demo funcional
4. **Incluye** toda la documentación legal
5. **Prueba** exhaustivamente antes de enviar
6. **Responde** rápidamente a feedback del revisor
7. **Sigue** las Human Interface Guidelines
8. **Evita** mencionar otras plataformas
9. **Asegura** que todo el contenido es apropiado
10. **Mantén** la app actualizada y funcional

---

**Nota:** Apple es más estricto que Google en sus revisiones. Asegúrate de cumplir todas las guidelines antes de enviar.