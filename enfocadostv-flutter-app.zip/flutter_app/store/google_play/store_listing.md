# Google Play Store - Información de la Tienda

## Información Básica

### Nombre de la App
**Español:** Enfocados en Dios TV - Biblia & Academia
**Inglés:** Focused on God TV - Bible & Academy

### Descripción Corta (80 caracteres)
**Español:** Biblia, videos cristianos, cursos y comunidad de fe en una sola app
**Inglés:** Bible, Christian videos, courses and faith community in one app

### Descripción Completa (4000 caracteres)

**Español:**
```
🙏 Enfocados en Dios TV - Tu Compañero Espiritual Diario

Descubre una experiencia cristiana completa con nuestra aplicación que combina el estudio bíblico profundo, contenido multimedia inspirador y una vibrante comunidad de fe.

📖 BIBLIA COMPLETA CON CONCORDANCIA STRONG
• Biblia Reina Valera 1960 completa
• Concordancia Strong para estudio profundo
• Versículos paralelos y referencias cruzadas
• Búsqueda avanzada por palabras y temas
• Marcadores y notas personales
• Lectura offline disponible
• Planes de lectura personalizados

🎥 VIDEOS Y ENSEÑANZAS
• Predicaciones en vivo y grabadas
• Serie de estudios bíblicos
• Testimonios inspiradores
• Contenido exclusivo del canal YouTube
• Reproducción en alta calidad
• Descarga para ver sin conexión

🎓 ACADEMIA BÍBLICA
• Cursos estructurados de teología
• Lecciones interactivas con evaluaciones
• Certificados de completación
• Progreso sincronizado
• Material de estudio descargable
• Desde nivel básico hasta avanzado

✨ VERSÍCULO DIARIO PERSONALIZADO
• IA que selecciona versículos según tu lectura
• Notificaciones diarias personalizables
• Compartir en redes sociales
• Reflexiones y devocionales

👥 COMUNIDAD DE FE
• Muro de oración interactivo
• Comparte peticiones y testimonios
• Eventos y actividades de la iglesia
• Chat con otros creyentes
• Grupos de estudio bíblico

💝 CARACTERÍSTICAS ADICIONALES
• Donaciones y diezmos seguros
• Calendario de eventos
• Transmisiones en vivo
• Modo oscuro para lectura nocturna
• Sincronización entre dispositivos
• Soporte multiidioma

🔔 MANTENTE CONECTADO
• Notificaciones de nuevos videos
• Recordatorios de oración
• Alertas de eventos especiales
• Actualizaciones de cursos

📱 DISEÑADO PARA TI
• Interfaz intuitiva y moderna
• Personalización completa
• Rendimiento optimizado
• Actualizaciones frecuentes

Únete a miles de creyentes que están fortaleciendo su fe diariamente con Enfocados en Dios TV.

¡Descarga ahora y comienza tu viaje espiritual!

Síguenos:
🌐 www.enfocadosendiostv.com
📺 YouTube: Enfocados en Dios TV
📧 Contacto: info@enfocadosendiostv.com
```

**Inglés:**
```
🙏 Focused on God TV - Your Daily Spiritual Companion

Discover a complete Christian experience with our app that combines deep Bible study, inspiring multimedia content, and a vibrant faith community.

📖 COMPLETE BIBLE WITH STRONG'S CONCORDANCE
• Complete Reina Valera 1960 Bible
• Strong's Concordance for deep study
• Parallel verses and cross references
• Advanced search by words and topics
• Bookmarks and personal notes
• Offline reading available
• Personalized reading plans

[... traducir el resto ...]
```

## Categorización

### Categoría Principal
Libros y obras de consulta

### Categoría Secundaria
Educación

### Etiquetas
- Biblia
- Cristianismo
- Estudio bíblico
- Educación cristiana
- Videos cristianos
- Comunidad de fe
- Devocionales
- Oración
- Iglesia
- Espiritualidad

## Clasificación de Contenido

### Clasificación por Edad
Para todos (E)

### Cuestionario de Contenido
- **Violencia:** No
- **Contenido Sexual:** No
- **Lenguaje Ofensivo:** No
- **Sustancias Controladas:** No
- **Contenido Generado por Usuarios:** Sí (moderado)

## Información de Contacto

### Email de Soporte
soporte@enfocadosendiostv.com

### Sitio Web
https://www.enfocadosendiostv.com

### Política de Privacidad
https://www.enfocadosendiostv.com/privacy

### Términos de Servicio
https://www.enfocadosendiostv.com/terms

## Requisitos del Sistema

### Mínimos
- Android 5.0 (API 21)
- 2GB RAM
- 100MB espacio libre

### Recomendados
- Android 8.0 o superior
- 4GB RAM
- 500MB espacio libre
- Conexión a Internet para contenido multimedia

## Capturas de Pantalla (Requeridas)

### Teléfono (mínimo 2, máximo 8)
1. `phone_1_home.png` - Pantalla principal con versículo del día
2. `phone_2_bible.png` - Lectura bíblica con Strong
3. `phone_3_videos.png` - Catálogo de videos
4. `phone_4_academy.png` - Cursos de la academia
5. `phone_5_community.png` - Muro de oración
6. `phone_6_live.png` - Transmisión en vivo
7. `phone_7_plans.png` - Planes de lectura
8. `phone_8_profile.png` - Perfil y logros

### Tablet 7" (opcional)
1. `tablet7_1_bible.png` - Vista de Biblia en tablet
2. `tablet7_2_videos.png` - Videos en pantalla grande

### Tablet 10" (opcional)
1. `tablet10_1_split.png` - Vista dividida Biblia/Notas
2. `tablet10_2_academy.png` - Academia en tablet

## Gráficos Promocionales

### Ícono de la App
- `app_icon_512.png` - 512x512px

### Gráfico Destacado
- `feature_graphic.png` - 1024x500px

### Banner de TV (opcional)
- `tv_banner.png` - 1280x720px

### Video Promocional (opcional)
- URL de YouTube del video promocional (máximo 2 minutos)

## Notas de la Versión

### Versión 1.0.0
**Lanzamiento inicial**
- Biblia completa con concordancia Strong
- Catálogo de videos cristianos
- Academia con cursos y certificados
- Versículo diario personalizado
- Muro de oración comunitario
- Planes de lectura bíblica
- Sistema de donaciones
- Notificaciones push
- Modo oscuro
- Soporte multiidioma (Español/Inglés)

## Precios y Distribución

### Precio
Gratis

### Compras dentro de la App
Sí (Donaciones voluntarias)

### Países de Distribución
Todos los países y territorios

### Programa de Acceso Anticipado
No

### Ads
No contiene anuncios