# 📱 Google Play Store - Checklist de Publicación

## ✅ Pre-requisitos

### Cuenta de Desarrollador
- [ ] Cuenta de Google Play Console activa ($25 USD pago único)
- [ ] Verificación de identidad completada
- [ ] Información fiscal configurada
- [ ] Método de pago configurado (para recibir pagos de donaciones)

### Preparación Legal
- [ ] Política de Privacidad publicada y accesible
- [ ] Términos de Servicio publicados
- [ ] Cumplimiento con COPPA (protección de menores)
- [ ] Cumplimiento con GDPR (usuarios europeos)
- [ ] Permisos de contenido (videos, imágenes, música)

## 🔧 Configuración Técnica

### Firma de la App
- [x] Keystore generado (`enfocadostv-release-key.jks`)
- [x] `key.properties` configurado
- [x] Backup del keystore en lugar seguro
- [ ] App Signing by Google Play habilitado (recomendado)

### Build de Producción
- [x] ProGuard rules configuradas
- [x] Minificación y ofuscación habilitadas
- [ ] App Bundle (.aab) generado
- [ ] Símbolos de debug para Crashlytics
- [ ] Pruebas en dispositivos físicos

### Optimización
- [ ] Imágenes optimizadas (WebP donde sea posible)
- [ ] Código no usado eliminado
- [ ] APK/Bundle size < 150MB
- [ ] Configuración de split APKs por ABI

## 📸 Recursos Gráficos

### Íconos
- [ ] Ícono de app 512x512px (PNG)
- [ ] Ícono adaptativo para Android 8.0+
- [ ] Ícono redondo para launchers circulares

### Capturas de Pantalla
- [ ] Mínimo 2 capturas para teléfono
- [ ] Capturas en alta resolución (1080x1920 o similar)
- [ ] Capturas que muestren funcionalidades principales
- [ ] Opcional: Capturas para tablet 7" y 10"

### Gráficos Promocionales
- [ ] Feature Graphic 1024x500px
- [ ] Video promocional (YouTube, opcional)
- [ ] Banner para Android TV (opcional)

## 📝 Información de la Tienda

### Textos
- [x] Título de la app (máx 30 caracteres)
- [x] Descripción corta (máx 80 caracteres)
- [x] Descripción completa (máx 4000 caracteres)
- [x] Notas de la versión
- [ ] Traducción a inglés (recomendado)

### Categorización
- [x] Categoría principal seleccionada
- [x] Categoría secundaria (opcional)
- [x] Etiquetas relevantes (máx 5)
- [x] Clasificación de contenido completada

### Información de Contacto
- [x] Email de soporte
- [x] Sitio web
- [x] Teléfono (opcional)
- [x] Dirección física (opcional)

## 🧪 Testing

### Pre-lanzamiento
- [ ] Test interno con equipo de desarrollo
- [ ] Test cerrado con beta testers (~50 usuarios)
- [ ] Test abierto (opcional)
- [ ] Reporte de Pre-launch (automático de Google)

### Pruebas Requeridas
- [ ] Instalación y desinstalación
- [ ] Flujo de registro/login
- [ ] Funciones principales sin conexión
- [ ] Notificaciones push
- [ ] Compras in-app (donaciones)
- [ ] Diferentes versiones de Android (5.0+)
- [ ] Diferentes tamaños de pantalla
- [ ] Orientación portrait/landscape

## 📊 Configuración Adicional

### Monetización
- [ ] Configurar productos in-app (donaciones)
- [ ] Merchant account vinculado
- [ ] Precios por región configurados

### Analytics
- [ ] Google Analytics configurado
- [ ] Firebase Analytics eventos
- [ ] Crashlytics habilitado
- [ ] Performance Monitoring activo

### Marketing
- [ ] Página de pre-registro (opcional)
- [ ] Experimentos de ficha de Play Store
- [ ] Campañas de Google Ads (opcional)
- [ ] Deep links configurados

## 🚀 Proceso de Publicación

### Primera Publicación
1. [ ] Crear nueva aplicación en Play Console
2. [ ] Completar toda la información requerida
3. [ ] Subir App Bundle firmado
4. [ ] Configurar países de distribución
5. [ ] Revisar y aceptar acuerdos
6. [ ] Enviar para revisión

### Tiempos Estimados
- Primera revisión: 2-3 días hábiles
- Actualizaciones: 2-24 horas
- Revisión adicional si hay problemas: 7 días

## ⚠️ Problemas Comunes

### Rechazos Frecuentes
- [ ] Permisos no justificados
- [ ] Contenido con copyright sin permiso
- [ ] Información engañosa
- [ ] Funcionalidad rota o crashes
- [ ] Violación de políticas de contenido
- [ ] Metadatos inapropiados

### Soluciones
- Justificar cada permiso en la descripción
- Incluir declaraciones de uso de datos
- Probar exhaustivamente antes de enviar
- Responder rápidamente a feedback de Google

## 📈 Post-Lanzamiento

### Monitoreo
- [ ] Ratings y reviews
- [ ] Crashes y ANRs
- [ ] Estadísticas de instalación
- [ ] Métricas de retención

### Mantenimiento
- [ ] Responder reviews negativos
- [ ] Actualizaciones regulares
- [ ] Corrección rápida de bugs
- [ ] Nuevas features basadas en feedback

## 📋 Comandos Útiles

```bash
# Generar keystore
./scripts/generate_keystore.sh

# Build para producción
./scripts/build_android.sh

# Verificar firma del APK/AAB
keytool -printcert -jarfile app-release.aab

# Instalar en dispositivo para prueba
adb install app-release.apk

# Ver logs del dispositivo
adb logcat | grep "com.enfocadosendiostv.app"
```

## 🔗 Enlaces Importantes

- [Google Play Console](https://play.google.com/console)
- [Políticas de Google Play](https://play.google.com/about/developer-content-policy/)
- [Guía de Publicación](https://support.google.com/googleplay/android-developer/answer/9859348)
- [Material Design Guidelines](https://material.io/design)
- [Android App Bundle](https://developer.android.com/guide/app-bundle)

---

**Nota:** Marca cada ítem conforme lo completes. Un lanzamiento exitoso requiere atención a todos estos detalles.