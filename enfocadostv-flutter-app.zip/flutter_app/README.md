# Enfocados en Dios TV - Mobile App 📱

Una aplicación móvil completa para estudio bíblico, contenido multimedia cristiano y educación espiritual.

## 🚀 Características Principales

- **📖 Biblia Completa**
  - Múltiples versiones bíblicas
  - Strong's Concordance integrado
  - Búsqueda avanzada
  - Notas y subrayado personalizado
  - Planes de lectura

- **🎬 Videos de YouTube**
  - Integración con canal de YouTube
  - Categorías (Debates, Prédicas, Entrevistas, etc.)
  - Reproducción offline
  - Historial de visualización

- **🎓 Academia Bíblica**
  - Cursos estructurados
  - Sistema de progreso
  - Certificados de finalización
  - Quizzes interactivos

- **✨ Versículo Diario con IA**
  - Selección inteligente basada en comportamiento
  - Reflexiones personalizadas
  - Compartir en redes sociales

- **👥 Comunidad**
  - Muro de oración
  - Testimonios
  - Grupos de estudio

## 🛠️ Stack Tecnológico

- **Flutter 3.16+** - Framework de desarrollo móvil
- **Dart 3.0+** - Lenguaje de programación
- **Riverpod 2.0** - Gestión de estado
- **Go Router** - Navegación
- **Dio** - Cliente HTTP
- **Firebase** - Backend services
- **YouTube Player** - Reproducción de videos

## 📋 Requisitos Previos

- Flutter SDK 3.16.0 o superior
- Dart SDK 3.0.0 o superior
- Android Studio / Xcode
- Cuenta de Firebase
- API Key de YouTube

## 🔧 Instalación

1. **Clonar el repositorio**
```bash
git clone https://github.com/enfocadosendiostv/mobile-app.git
cd mobile-app/flutter_app
```

2. **Instalar dependencias**
```bash
flutter pub get
```

3. **Configurar variables de entorno**
```bash
cp .env.example .env
# Editar .env con tus credenciales
```

4. **Configurar Firebase**
```bash
# Android
# Copiar google-services.json a android/app/

# iOS
# Copiar GoogleService-Info.plist a ios/Runner/
```

5. **Generar código**
```bash
flutter pub run build_runner build --delete-conflicting-outputs
```

## 🏃‍♂️ Ejecutar la Aplicación

### Desarrollo
```bash
# Android
flutter run --flavor dev -t lib/main_dev.dart

# iOS
flutter run --flavor dev -t lib/main_dev.dart
```

### Staging
```bash
flutter run --flavor staging -t lib/main_staging.dart
```

### Producción
```bash
flutter run --flavor prod -t lib/main.dart
```

## 📱 Compilar para Distribución

### Android

#### APK
```bash
flutter build apk --release --flavor prod -t lib/main.dart
```

#### App Bundle (Recomendado para Play Store)
```bash
flutter build appbundle --release --flavor prod -t lib/main.dart
```

### iOS

```bash
flutter build ios --release --flavor prod -t lib/main.dart
```

Luego abrir en Xcode y archivar para App Store.

## 🧪 Testing

```bash
# Unit tests
flutter test

# Integration tests
flutter test integration_test

# Coverage
flutter test --coverage
```

## 📂 Estructura del Proyecto

```
lib/
├── core/                 # Configuración central
│   ├── api/             # Cliente HTTP y configuración
│   ├── constants/       # Constantes de la app
│   ├── router/          # Configuración de navegación
│   ├── services/        # Servicios globales
│   └── themes/          # Temas y estilos
├── data/                # Capa de datos
│   ├── models/          # Modelos de datos
│   └── repositories/    # Repositorios
├── presentation/        # Capa de presentación
│   ├── providers/       # Providers (Riverpod)
│   ├── screens/         # Pantallas
│   └── widgets/         # Widgets reutilizables
└── main.dart           # Punto de entrada

assets/
├── animations/          # Animaciones Lottie
├── fonts/              # Fuentes tipográficas
├── icons/              # Iconos personalizados
└── images/             # Imágenes

android/                # Configuración Android
ios/                    # Configuración iOS
test/                   # Tests unitarios
integration_test/       # Tests de integración
```

## 🔐 Configuración de Firebase

1. Crear proyecto en [Firebase Console](https://console.firebase.google.com)
2. Agregar app Android/iOS
3. Descargar archivos de configuración
4. Habilitar servicios necesarios:
   - Authentication
   - Cloud Firestore
   - Cloud Messaging
   - Analytics
   - Crashlytics

## 🎨 Personalización

### Colores
Editar `lib/core/themes/app_colors.dart`:
```dart
static const Color primary = Color(0xFFCC0000); // Rojo
static const Color gold = Color(0xFFFFD700);    // Dorado
```

### Fuentes
Agregar fuentes en `pubspec.yaml` y `assets/fonts/`

## 📊 Analytics y Monitoreo

La app incluye:
- Firebase Analytics
- Firebase Crashlytics
- Logging personalizado

## 🚀 CI/CD

### GitHub Actions

El proyecto incluye workflows para:
- Build automático
- Tests
- Distribución a testers
- Deploy a stores

## 📝 Licencia

Todos los derechos reservados © 2024 Enfocados en Dios TV

## 👥 Equipo

- **Desarrollo**: [Tu nombre]
- **Diseño**: [Diseñador]
- **Backend**: [Backend Dev]

## 📞 Soporte

- Email: soporte@enfocadosendiostv.com
- Website: https://www.enfocadosendiostv.com
- Issues: https://github.com/enfocadosendiostv/mobile-app/issues

## 🙏 Agradecimientos

Gracias a todos los que hacen posible este ministerio digital.

---

**Enfocados en Dios TV** - Llevando la palabra de Dios al mundo digital