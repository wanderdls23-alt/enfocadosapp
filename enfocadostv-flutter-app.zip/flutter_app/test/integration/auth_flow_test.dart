import 'package:flutter_test/flutter_test.dart';
import 'package:integration_test/integration_test.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:enfocadostv/main.dart' as app;

void main() {
  IntegrationTestWidgetsFlutterBinding.ensureInitialized();

  group('Auth Flow Integration Tests', () {
    testWidgets('Usuario puede completar flujo de registro y login',
        (WidgetTester tester) async {
      // Iniciar la app
      app.main();
      await tester.pumpAndSettle();

      // Verificar que estamos en la pantalla de splash
      expect(find.text('Enfocados en Dios TV'), findsOneWidget);

      // Esperar a que termine el splash
      await tester.pumpAndSettle(const Duration(seconds: 3));

      // Verificar que estamos en la pantalla de login
      expect(find.text('Bienvenido'), findsOneWidget);

      // Tap en registrarse
      await tester.tap(find.text('¿No tienes cuenta? Regístrate'));
      await tester.pumpAndSettle();

      // Verificar que estamos en registro
      expect(find.text('Crear Cuenta'), findsOneWidget);

      // Llenar formulario de registro
      final timestamp = DateTime.now().millisecondsSinceEpoch;
      final testEmail = 'test$timestamp@enfocadosendiostv.com';

      await tester.enterText(
        find.byKey(const Key('register_name_field')),
        'Test User',
      );
      await tester.enterText(
        find.byKey(const Key('register_email_field')),
        testEmail,
      );
      await tester.enterText(
        find.byKey(const Key('register_password_field')),
        'TestPassword123!',
      );
      await tester.enterText(
        find.byKey(const Key('register_confirm_password_field')),
        'TestPassword123!',
      );

      // Aceptar términos
      await tester.tap(find.byType(Checkbox));
      await tester.pumpAndSettle();

      // Registrarse
      await tester.tap(find.text('REGISTRARSE'));
      await tester.pumpAndSettle();

      // Verificar que llegamos al home
      expect(find.text('Hola, Test User'), findsOneWidget);
      expect(find.byIcon(Icons.home), findsOneWidget);

      // Hacer logout
      await tester.tap(find.byIcon(Icons.more_horiz));
      await tester.pumpAndSettle();

      await tester.tap(find.text('Cerrar Sesión'));
      await tester.pumpAndSettle();

      // Confirmar logout
      await tester.tap(find.text('CERRAR SESIÓN'));
      await tester.pumpAndSettle();

      // Verificar que volvimos al login
      expect(find.text('Bienvenido'), findsOneWidget);

      // Ahora hacer login con la cuenta creada
      await tester.enterText(
        find.byKey(const Key('email_field')),
        testEmail,
      );
      await tester.enterText(
        find.byKey(const Key('password_field')),
        'TestPassword123!',
      );

      await tester.tap(find.text('INICIAR SESIÓN'));
      await tester.pumpAndSettle();

      // Verificar que el login fue exitoso
      expect(find.text('Hola, Test User'), findsOneWidget);
    });

    testWidgets('Usuario puede recuperar contraseña',
        (WidgetTester tester) async {
      // Iniciar la app
      app.main();
      await tester.pumpAndSettle();

      // Esperar splash
      await tester.pumpAndSettle(const Duration(seconds: 3));

      // Tap en olvidé contraseña
      await tester.tap(find.text('¿Olvidaste tu contraseña?'));
      await tester.pumpAndSettle();

      // Verificar diálogo
      expect(find.text('Recuperar Contraseña'), findsOneWidget);

      // Ingresar email
      await tester.enterText(
        find.byKey(const Key('reset_email_field')),
        'test@enfocadosendiostv.com',
      );

      // Enviar
      await tester.tap(find.text('ENVIAR'));
      await tester.pumpAndSettle();

      // Verificar mensaje de éxito
      expect(
        find.text('Se ha enviado un email con instrucciones'),
        findsOneWidget,
      );

      // Cerrar diálogo
      await tester.tap(find.text('OK'));
      await tester.pumpAndSettle();

      // Verificar que volvimos al login
      expect(find.text('Bienvenido'), findsOneWidget);
    });

    testWidgets('Login con credenciales inválidas muestra error',
        (WidgetTester tester) async {
      // Iniciar la app
      app.main();
      await tester.pumpAndSettle();

      // Esperar splash
      await tester.pumpAndSettle(const Duration(seconds: 3));

      // Intentar login con credenciales incorrectas
      await tester.enterText(
        find.byKey(const Key('email_field')),
        'wrong@email.com',
      );
      await tester.enterText(
        find.byKey(const Key('password_field')),
        'wrongpassword',
      );

      await tester.tap(find.text('INICIAR SESIÓN'));
      await tester.pumpAndSettle();

      // Verificar mensaje de error
      expect(
        find.text('Credenciales inválidas'),
        findsOneWidget,
      );

      // Verificar que seguimos en login
      expect(find.text('Bienvenido'), findsOneWidget);
    });
  });

  group('Bible Navigation Integration Tests', () {
    testWidgets('Usuario puede navegar por la Biblia',
        (WidgetTester tester) async {
      // Setup - Login primero
      app.main();
      await tester.pumpAndSettle();
      await tester.pumpAndSettle(const Duration(seconds: 3));

      // Login con cuenta de prueba
      await tester.enterText(
        find.byKey(const Key('email_field')),
        'demo@enfocadosendiostv.com',
      );
      await tester.enterText(
        find.byKey(const Key('password_field')),
        'Demo2024!',
      );
      await tester.tap(find.text('INICIAR SESIÓN'));
      await tester.pumpAndSettle();

      // Navegar a la Biblia
      await tester.tap(find.byIcon(Icons.menu_book));
      await tester.pumpAndSettle();

      // Verificar que estamos en la Biblia
      expect(find.text('Biblia'), findsOneWidget);
      expect(find.text('Antiguo Testamento'), findsOneWidget);
      expect(find.text('Nuevo Testamento'), findsOneWidget);

      // Seleccionar Génesis
      await tester.tap(find.text('Génesis'));
      await tester.pumpAndSettle();

      // Verificar que se muestran los capítulos
      expect(find.text('Capítulo 1'), findsOneWidget);

      // Seleccionar capítulo 1
      await tester.tap(find.text('Capítulo 1'));
      await tester.pumpAndSettle();

      // Verificar que se muestra el texto
      expect(
        find.textContaining('En el principio'),
        findsOneWidget,
      );

      // Probar búsqueda
      await tester.tap(find.byIcon(Icons.search));
      await tester.pumpAndSettle();

      await tester.enterText(
        find.byKey(const Key('search_field')),
        'amor de Dios',
      );
      await tester.tap(find.byIcon(Icons.search));
      await tester.pumpAndSettle();

      // Verificar resultados
      expect(find.text('Resultados de búsqueda'), findsOneWidget);

      // Volver al inicio
      await tester.tap(find.byIcon(Icons.arrow_back));
      await tester.pumpAndSettle();
    });

    testWidgets('Usuario puede marcar versículos como favoritos',
        (WidgetTester tester) async {
      // Login y navegar a un versículo
      app.main();
      await tester.pumpAndSettle();
      await tester.pumpAndSettle(const Duration(seconds: 3));

      await tester.enterText(
        find.byKey(const Key('email_field')),
        'demo@enfocadosendiostv.com',
      );
      await tester.enterText(
        find.byKey(const Key('password_field')),
        'Demo2024!',
      );
      await tester.tap(find.text('INICIAR SESIÓN'));
      await tester.pumpAndSettle();

      // Ir a la Biblia
      await tester.tap(find.byIcon(Icons.menu_book));
      await tester.pumpAndSettle();

      // Seleccionar Juan
      await tester.tap(find.text('Juan'));
      await tester.pumpAndSettle();

      // Seleccionar capítulo 3
      await tester.tap(find.text('Capítulo 3'));
      await tester.pumpAndSettle();

      // Long press en versículo 16
      await tester.longPress(
        find.textContaining('de tal manera amó Dios'),
      );
      await tester.pumpAndSettle();

      // Verificar menú contextual
      expect(find.text('Opciones'), findsOneWidget);

      // Marcar como favorito
      await tester.tap(find.text('Agregar a favoritos'));
      await tester.pumpAndSettle();

      // Verificar confirmación
      expect(
        find.text('Versículo agregado a favoritos'),
        findsOneWidget,
      );

      // Ir a favoritos
      await tester.tap(find.byIcon(Icons.bookmark));
      await tester.pumpAndSettle();

      // Verificar que el versículo está en favoritos
      expect(find.text('Juan 3:16'), findsOneWidget);
    });
  });

  group('Academy Flow Integration Tests', () {
    testWidgets('Usuario puede inscribirse y completar un curso',
        (WidgetTester tester) async {
      // Login
      app.main();
      await tester.pumpAndSettle();
      await tester.pumpAndSettle(const Duration(seconds: 3));

      await tester.enterText(
        find.byKey(const Key('email_field')),
        'demo@enfocadosendiostv.com',
      );
      await tester.enterText(
        find.byKey(const Key('password_field')),
        'Demo2024!',
      );
      await tester.tap(find.text('INICIAR SESIÓN'));
      await tester.pumpAndSettle();

      // Navegar a Academia
      await tester.tap(find.byIcon(Icons.school));
      await tester.pumpAndSettle();

      // Verificar que estamos en Academia
      expect(find.text('Academia'), findsOneWidget);
      expect(find.text('Cursos Disponibles'), findsOneWidget);

      // Seleccionar un curso
      await tester.tap(find.text('Fundamentos de la Fe').first);
      await tester.pumpAndSettle();

      // Verificar detalles del curso
      expect(find.text('Acerca del curso'), findsOneWidget);
      expect(find.text('INSCRIBIRSE'), findsOneWidget);

      // Inscribirse
      await tester.tap(find.text('INSCRIBIRSE'));
      await tester.pumpAndSettle();

      // Verificar inscripción exitosa
      expect(find.text('CONTINUAR'), findsOneWidget);

      // Iniciar primera lección
      await tester.tap(find.text('Lección 1'));
      await tester.pumpAndSettle();

      // Verificar contenido de la lección
      expect(find.text('Contenido de la lección'), findsOneWidget);

      // Marcar como completada
      await tester.tap(find.text('MARCAR COMO COMPLETADA'));
      await tester.pumpAndSettle();

      // Verificar progreso
      expect(find.byIcon(Icons.check_circle), findsOneWidget);
    });
  });
}