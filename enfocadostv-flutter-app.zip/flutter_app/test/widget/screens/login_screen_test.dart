import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:mockito/mockito.dart';
import 'package:mockito/annotations.dart';
import 'package:enfocadostv/presentation/screens/auth/login_screen.dart';
import 'package:enfocadostv/presentation/providers/auth_provider.dart';
import 'package:enfocadostv/data/models/user_model.dart';

@GenerateMocks([AuthNotifier])
import 'login_screen_test.mocks.dart';

void main() {
  late MockAuthNotifier mockAuthNotifier;

  setUp(() {
    mockAuthNotifier = MockAuthNotifier();
  });

  Widget createTestWidget(Widget child) {
    return ProviderScope(
      overrides: [
        authProvider.overrideWith((ref) => mockAuthNotifier),
      ],
      child: MaterialApp(
        home: child,
      ),
    );
  }

  group('LoginScreen Widget Tests', () {
    testWidgets('Pantalla de login muestra todos los elementos necesarios',
        (WidgetTester tester) async {
      // Arrange
      when(mockAuthNotifier.state).thenReturn(AuthState());

      // Act
      await tester.pumpWidget(createTestWidget(const LoginScreen()));

      // Assert
      expect(find.text('Bienvenido'), findsOneWidget);
      expect(find.text('Inicia sesión para continuar'), findsOneWidget);
      expect(find.byType(TextField), findsNWidgets(2)); // Email y contraseña
      expect(find.text('INICIAR SESIÓN'), findsOneWidget);
      expect(find.text('¿Olvidaste tu contraseña?'), findsOneWidget);
      expect(find.text('¿No tienes cuenta? Regístrate'), findsOneWidget);
      expect(find.text('Continuar con Google'), findsOneWidget);
    });

    testWidgets('Validación de campos vacíos muestra errores',
        (WidgetTester tester) async {
      // Arrange
      when(mockAuthNotifier.state).thenReturn(AuthState());

      // Act
      await tester.pumpWidget(createTestWidget(const LoginScreen()));

      // Tap en botón de login sin llenar campos
      await tester.tap(find.text('INICIAR SESIÓN'));
      await tester.pump();

      // Assert
      expect(find.text('El email es requerido'), findsOneWidget);
      expect(find.text('La contraseña es requerida'), findsOneWidget);
    });

    testWidgets('Validación de email inválido muestra error',
        (WidgetTester tester) async {
      // Arrange
      when(mockAuthNotifier.state).thenReturn(AuthState());

      // Act
      await tester.pumpWidget(createTestWidget(const LoginScreen()));

      // Ingresar email inválido
      await tester.enterText(
        find.byKey(const Key('email_field')),
        'emailinvalido',
      );
      await tester.enterText(
        find.byKey(const Key('password_field')),
        'password123',
      );

      await tester.tap(find.text('INICIAR SESIÓN'));
      await tester.pump();

      // Assert
      expect(find.text('Ingresa un email válido'), findsOneWidget);
    });

    testWidgets('Login exitoso navega a home',
        (WidgetTester tester) async {
      // Arrange
      final user = UserModel(
        id: '1',
        email: 'test@enfocadosendiostv.com',
        name: 'Test User',
        createdAt: DateTime.now(),
      );

      when(mockAuthNotifier.state).thenReturn(AuthState());
      when(mockAuthNotifier.login(any, any))
          .thenAnswer((_) async {
        when(mockAuthNotifier.state).thenReturn(
          AuthState(isAuthenticated: true, user: user),
        );
      });

      // Act
      await tester.pumpWidget(createTestWidget(const LoginScreen()));

      // Llenar campos
      await tester.enterText(
        find.byKey(const Key('email_field')),
        'test@enfocadosendiostv.com',
      );
      await tester.enterText(
        find.byKey(const Key('password_field')),
        'password123',
      );

      // Tap login
      await tester.tap(find.text('INICIAR SESIÓN'));
      await tester.pumpAndSettle();

      // Assert
      verify(mockAuthNotifier.login(
        'test@enfocadosendiostv.com',
        'password123',
      )).called(1);
    });

    testWidgets('Toggle de visibilidad de contraseña funciona',
        (WidgetTester tester) async {
      // Arrange
      when(mockAuthNotifier.state).thenReturn(AuthState());

      // Act
      await tester.pumpWidget(createTestWidget(const LoginScreen()));

      // Verificar que inicialmente la contraseña está oculta
      final passwordField = find.byKey(const Key('password_field'));
      TextField textField = tester.widget(passwordField);
      expect(textField.obscureText, true);

      // Tap en icono de visibilidad
      await tester.tap(find.byIcon(Icons.visibility));
      await tester.pump();

      // Verificar que ahora la contraseña es visible
      textField = tester.widget(passwordField);
      expect(textField.obscureText, false);
    });

    testWidgets('Botón de Google login llama al método correcto',
        (WidgetTester tester) async {
      // Arrange
      when(mockAuthNotifier.state).thenReturn(AuthState());
      when(mockAuthNotifier.loginWithGoogle()).thenAnswer((_) async {});

      // Act
      await tester.pumpWidget(createTestWidget(const LoginScreen()));

      await tester.tap(find.text('Continuar con Google'));
      await tester.pumpAndSettle();

      // Assert
      verify(mockAuthNotifier.loginWithGoogle()).called(1);
    });

    testWidgets('Muestra indicador de carga durante login',
        (WidgetTester tester) async {
      // Arrange
      when(mockAuthNotifier.state).thenReturn(
        AuthState(isLoading: true),
      );

      // Act
      await tester.pumpWidget(createTestWidget(const LoginScreen()));

      // Assert
      expect(find.byType(CircularProgressIndicator), findsOneWidget);
      expect(find.text('INICIAR SESIÓN'), findsNothing);
    });

    testWidgets('Muestra error cuando login falla',
        (WidgetTester tester) async {
      // Arrange
      when(mockAuthNotifier.state).thenReturn(
        AuthState(error: 'Credenciales inválidas'),
      );

      // Act
      await tester.pumpWidget(createTestWidget(const LoginScreen()));

      // Assert
      expect(find.text('Credenciales inválidas'), findsOneWidget);
      expect(find.byIcon(Icons.error_outline), findsOneWidget);
    });

    testWidgets('Link de registro navega a pantalla de registro',
        (WidgetTester tester) async {
      // Arrange
      when(mockAuthNotifier.state).thenReturn(AuthState());

      // Act
      await tester.pumpWidget(createTestWidget(const LoginScreen()));

      await tester.tap(find.text('¿No tienes cuenta? Regístrate'));
      await tester.pumpAndSettle();

      // Assert - Verificar navegación
      // En una app real, verificarías la navegación
    });

    testWidgets('Link de recuperar contraseña abre diálogo',
        (WidgetTester tester) async {
      // Arrange
      when(mockAuthNotifier.state).thenReturn(AuthState());

      // Act
      await tester.pumpWidget(createTestWidget(const LoginScreen()));

      await tester.tap(find.text('¿Olvidaste tu contraseña?'));
      await tester.pumpAndSettle();

      // Assert
      expect(find.text('Recuperar Contraseña'), findsOneWidget);
      expect(find.text('Ingresa tu email para recibir instrucciones'),
          findsOneWidget);
      expect(find.text('ENVIAR'), findsOneWidget);
      expect(find.text('CANCELAR'), findsOneWidget);
    });

    testWidgets('Recuperar contraseña con email válido',
        (WidgetTester tester) async {
      // Arrange
      when(mockAuthNotifier.state).thenReturn(AuthState());
      when(mockAuthNotifier.sendPasswordResetEmail(any))
          .thenAnswer((_) async => true);

      // Act
      await tester.pumpWidget(createTestWidget(const LoginScreen()));

      // Abrir diálogo
      await tester.tap(find.text('¿Olvidaste tu contraseña?'));
      await tester.pumpAndSettle();

      // Ingresar email
      await tester.enterText(
        find.byKey(const Key('reset_email_field')),
        'test@enfocadosendiostv.com',
      );

      // Enviar
      await tester.tap(find.text('ENVIAR'));
      await tester.pumpAndSettle();

      // Assert
      verify(mockAuthNotifier.sendPasswordResetEmail(
        'test@enfocadosendiostv.com',
      )).called(1);

      // Verificar mensaje de éxito
      expect(find.text('Email enviado exitosamente'), findsOneWidget);
    });
  });

  group('LoginScreen Responsiveness Tests', () {
    testWidgets('Layout se adapta a pantalla pequeña',
        (WidgetTester tester) async {
      // Arrange
      when(mockAuthNotifier.state).thenReturn(AuthState());

      // Act - Simular pantalla pequeña
      tester.binding.window.physicalSizeTestValue = const Size(320, 568);
      tester.binding.window.devicePixelRatioTestValue = 1.0;

      await tester.pumpWidget(createTestWidget(const LoginScreen()));

      // Assert
      expect(find.byType(SingleChildScrollView), findsOneWidget);
      expect(find.byType(TextField), findsNWidgets(2));
    });

    testWidgets('Layout se adapta a tablet',
        (WidgetTester tester) async {
      // Arrange
      when(mockAuthNotifier.state).thenReturn(AuthState());

      // Act - Simular tablet
      tester.binding.window.physicalSizeTestValue = const Size(1024, 768);
      tester.binding.window.devicePixelRatioTestValue = 2.0;

      await tester.pumpWidget(createTestWidget(const LoginScreen()));

      // Assert
      expect(find.byType(Container), findsWidgets);
      expect(find.byType(TextField), findsNWidgets(2));
    });
  });
}