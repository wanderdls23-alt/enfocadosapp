import 'package:flutter_test/flutter_test.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:mockito/mockito.dart';
import 'package:mockito/annotations.dart';
import 'package:enfocadostv/data/repositories/auth_repository.dart';
import 'package:enfocadostv/data/models/user_model.dart';
import 'package:enfocadostv/presentation/providers/auth_provider.dart';

@GenerateMocks([AuthRepository])
import 'auth_provider_test.mocks.dart';

void main() {
  late ProviderContainer container;
  late MockAuthRepository mockAuthRepository;

  setUp(() {
    mockAuthRepository = MockAuthRepository();
    container = ProviderContainer(
      overrides: [
        authRepositoryProvider.overrideWithValue(mockAuthRepository),
      ],
    );
  });

  tearDown(() {
    container.dispose();
  });

  group('AuthProvider Tests', () {
    test('Estado inicial debe ser no autenticado', () {
      final authState = container.read(authProvider);

      expect(authState.isAuthenticated, false);
      expect(authState.user, isNull);
      expect(authState.isLoading, false);
      expect(authState.error, isNull);
    });

    test('Login exitoso debe actualizar el estado', () async {
      // Arrange
      final testUser = UserModel(
        id: '123',
        email: 'test@enfocadosendiostv.com',
        name: 'Test User',
        createdAt: DateTime.now(),
      );

      when(mockAuthRepository.login(any, any))
          .thenAnswer((_) async => testUser);

      // Act
      await container.read(authProvider.notifier).login(
        'test@enfocadosendiostv.com',
        'password123',
      );

      // Assert
      final authState = container.read(authProvider);
      expect(authState.isAuthenticated, true);
      expect(authState.user, equals(testUser));
      expect(authState.error, isNull);

      verify(mockAuthRepository.login(
        'test@enfocadosendiostv.com',
        'password123',
      )).called(1);
    });

    test('Login fallido debe mostrar error', () async {
      // Arrange
      when(mockAuthRepository.login(any, any))
          .thenThrow(Exception('Credenciales inválidas'));

      // Act
      await container.read(authProvider.notifier).login(
        'wrong@email.com',
        'wrongpassword',
      );

      // Assert
      final authState = container.read(authProvider);
      expect(authState.isAuthenticated, false);
      expect(authState.user, isNull);
      expect(authState.error, contains('Credenciales inválidas'));
    });

    test('Registro exitoso debe crear usuario y autenticar', () async {
      // Arrange
      final newUser = UserModel(
        id: '456',
        email: 'new@enfocadosendiostv.com',
        name: 'New User',
        createdAt: DateTime.now(),
      );

      when(mockAuthRepository.register(any, any, any))
          .thenAnswer((_) async => newUser);

      // Act
      await container.read(authProvider.notifier).register(
        'new@enfocadosendiostv.com',
        'password123',
        'New User',
      );

      // Assert
      final authState = container.read(authProvider);
      expect(authState.isAuthenticated, true);
      expect(authState.user?.email, equals('new@enfocadosendiostv.com'));
      expect(authState.user?.name, equals('New User'));
    });

    test('Logout debe limpiar el estado', () async {
      // Arrange
      final testUser = UserModel(
        id: '789',
        email: 'logout@enfocadosendiostv.com',
        name: 'Logout User',
        createdAt: DateTime.now(),
      );

      when(mockAuthRepository.login(any, any))
          .thenAnswer((_) async => testUser);
      when(mockAuthRepository.logout())
          .thenAnswer((_) async => {});

      // Login primero
      await container.read(authProvider.notifier).login(
        'logout@enfocadosendiostv.com',
        'password123',
      );

      // Act - Logout
      await container.read(authProvider.notifier).logout();

      // Assert
      final authState = container.read(authProvider);
      expect(authState.isAuthenticated, false);
      expect(authState.user, isNull);

      verify(mockAuthRepository.logout()).called(1);
    });

    test('CheckAuthStatus debe verificar token válido', () async {
      // Arrange
      final testUser = UserModel(
        id: '999',
        email: 'check@enfocadosendiostv.com',
        name: 'Check User',
        createdAt: DateTime.now(),
      );

      when(mockAuthRepository.getCurrentUser())
          .thenAnswer((_) async => testUser);

      // Act
      await container.read(authProvider.notifier).checkAuthStatus();

      // Assert
      final authState = container.read(authProvider);
      expect(authState.isAuthenticated, true);
      expect(authState.user, equals(testUser));
    });

    test('CheckAuthStatus con token inválido debe desautenticar', () async {
      // Arrange
      when(mockAuthRepository.getCurrentUser())
          .thenAnswer((_) async => null);

      // Act
      await container.read(authProvider.notifier).checkAuthStatus();

      // Assert
      final authState = container.read(authProvider);
      expect(authState.isAuthenticated, false);
      expect(authState.user, isNull);
    });

    test('Login con Google debe funcionar correctamente', () async {
      // Arrange
      final googleUser = UserModel(
        id: 'google123',
        email: 'google@enfocadosendiostv.com',
        name: 'Google User',
        createdAt: DateTime.now(),
        authProvider: 'google',
      );

      when(mockAuthRepository.loginWithGoogle())
          .thenAnswer((_) async => googleUser);

      // Act
      await container.read(authProvider.notifier).loginWithGoogle();

      // Assert
      final authState = container.read(authProvider);
      expect(authState.isAuthenticated, true);
      expect(authState.user?.authProvider, equals('google'));

      verify(mockAuthRepository.loginWithGoogle()).called(1);
    });

    test('Estado de loading debe actualizarse correctamente', () async {
      // Arrange
      when(mockAuthRepository.login(any, any))
          .thenAnswer((_) async {
            await Future.delayed(Duration(milliseconds: 100));
            return UserModel(
              id: '1',
              email: 'test@test.com',
              name: 'Test',
              createdAt: DateTime.now(),
            );
          });

      // Act
      final future = container.read(authProvider.notifier).login(
        'test@test.com',
        'password',
      );

      // Assert - Check loading state immediately
      expect(container.read(authProvider).isLoading, true);

      await future;

      // Assert - Check loading state after completion
      expect(container.read(authProvider).isLoading, false);
    });
  });

  group('AuthProvider Password Reset Tests', () {
    test('Solicitud de reset password exitosa', () async {
      // Arrange
      when(mockAuthRepository.sendPasswordResetEmail(any))
          .thenAnswer((_) async => true);

      // Act
      final result = await container.read(authProvider.notifier)
          .sendPasswordResetEmail('reset@enfocadosendiostv.com');

      // Assert
      expect(result, true);
      verify(mockAuthRepository.sendPasswordResetEmail(
        'reset@enfocadosendiostv.com'
      )).called(1);
    });

    test('Reset password con email inválido debe fallar', () async {
      // Arrange
      when(mockAuthRepository.sendPasswordResetEmail(any))
          .thenThrow(Exception('Email no encontrado'));

      // Act
      final result = await container.read(authProvider.notifier)
          .sendPasswordResetEmail('notfound@email.com');

      // Assert
      expect(result, false);
      final authState = container.read(authProvider);
      expect(authState.error, contains('Email no encontrado'));
    });
  });

  group('AuthProvider Token Management Tests', () {
    test('Token refresh exitoso debe mantener sesión', () async {
      // Arrange
      final updatedUser = UserModel(
        id: '123',
        email: 'refresh@enfocadosendiostv.com',
        name: 'Refresh User',
        createdAt: DateTime.now(),
      );

      when(mockAuthRepository.refreshToken())
          .thenAnswer((_) async => 'new_token');
      when(mockAuthRepository.getCurrentUser())
          .thenAnswer((_) async => updatedUser);

      // Act
      await container.read(authProvider.notifier).refreshToken();

      // Assert
      final authState = container.read(authProvider);
      expect(authState.isAuthenticated, true);
      expect(authState.user, equals(updatedUser));
    });

    test('Token refresh fallido debe desautenticar', () async {
      // Arrange
      when(mockAuthRepository.refreshToken())
          .thenThrow(Exception('Token expirado'));

      // Act
      await container.read(authProvider.notifier).refreshToken();

      // Assert
      final authState = container.read(authProvider);
      expect(authState.isAuthenticated, false);
      expect(authState.user, isNull);
    });
  });
}