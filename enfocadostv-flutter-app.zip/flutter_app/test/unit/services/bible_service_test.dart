import 'package:flutter_test/flutter_test.dart';
import 'package:mockito/mockito.dart';
import 'package:mockito/annotations.dart';
import 'package:dio/dio.dart';
import 'package:enfocadostv/services/bible_service.dart';
import 'package:enfocadostv/data/models/bible_models.dart';

@GenerateMocks([Dio])
import 'bible_service_test.mocks.dart';

void main() {
  late BibleService bibleService;
  late MockDio mockDio;

  setUp(() {
    mockDio = MockDio();
    bibleService = BibleService(dio: mockDio);
  });

  group('BibleService Tests', () {
    test('Obtener libros de la Biblia exitosamente', () async {
      // Arrange
      final mockResponse = Response(
        data: {
          'books': [
            {
              'id': 1,
              'name': 'Génesis',
              'testament': 'old',
              'chapters': 50,
              'abbreviation': 'Gen',
            },
            {
              'id': 40,
              'name': 'Mateo',
              'testament': 'new',
              'chapters': 28,
              'abbreviation': 'Mt',
            },
          ],
        },
        statusCode: 200,
        requestOptions: RequestOptions(path: '/api/bible/books'),
      );

      when(mockDio.get(any)).thenAnswer((_) async => mockResponse);

      // Act
      final books = await bibleService.getBooks();

      // Assert
      expect(books, isNotEmpty);
      expect(books.length, 2);
      expect(books[0].name, 'Génesis');
      expect(books[0].testament, 'old');
      expect(books[1].name, 'Mateo');
      expect(books[1].testament, 'new');
    });

    test('Buscar versículos con query debe retornar resultados', () async {
      // Arrange
      final mockResponse = Response(
        data: {
          'results': [
            {
              'book': 'Juan',
              'chapter': 3,
              'verse': 16,
              'text': 'Porque de tal manera amó Dios al mundo...',
              'reference': 'Juan 3:16',
            },
          ],
          'total': 1,
        },
        statusCode: 200,
        requestOptions: RequestOptions(path: '/api/bible/search'),
      );

      when(mockDio.get(any, queryParameters: anyNamed('queryParameters')))
          .thenAnswer((_) async => mockResponse);

      // Act
      final results = await bibleService.searchVerses('amor de Dios');

      // Assert
      expect(results, isNotEmpty);
      expect(results[0].reference, 'Juan 3:16');
      expect(results[0].text, contains('amó Dios'));
    });

    test('Obtener capítulo con versículos', () async {
      // Arrange
      final mockResponse = Response(
        data: {
          'chapter': {
            'book': 'Salmos',
            'number': 23,
            'verses': [
              {
                'number': 1,
                'text': 'Jehová es mi pastor; nada me faltará.',
                'strongNumbers': ['H3068', 'H7462'],
              },
              {
                'number': 2,
                'text': 'En lugares de delicados pastos me hará descansar...',
                'strongNumbers': ['H4999', 'H7257'],
              },
            ],
          },
        },
        statusCode: 200,
        requestOptions: RequestOptions(path: '/api/bible/chapter'),
      );

      when(mockDio.get(any, queryParameters: anyNamed('queryParameters')))
          .thenAnswer((_) async => mockResponse);

      // Act
      final chapter = await bibleService.getChapter('Salmos', 23);

      // Assert
      expect(chapter.book, 'Salmos');
      expect(chapter.number, 23);
      expect(chapter.verses.length, 2);
      expect(chapter.verses[0].text, contains('pastor'));
      expect(chapter.verses[0].strongNumbers, isNotEmpty);
    });

    test('Obtener concordancia Strong exitosamente', () async {
      // Arrange
      final mockResponse = Response(
        data: {
          'strong': {
            'number': 'H3068',
            'original': 'יהוה',
            'transliteration': 'Yehovah',
            'pronunciation': 'yeh-ho-vaw',
            'definition': 'El nombre propio del Dios de Israel',
            'usage': 'Jehová, el Señor',
            'references': [
              'Genesis 2:4',
              'Exodus 3:15',
              'Psalms 23:1',
            ],
          },
        },
        statusCode: 200,
        requestOptions: RequestOptions(path: '/api/bible/strong'),
      );

      when(mockDio.get(any, queryParameters: anyNamed('queryParameters')))
          .thenAnswer((_) async => mockResponse);

      // Act
      final strong = await bibleService.getStrongDefinition('H3068');

      // Assert
      expect(strong.number, 'H3068');
      expect(strong.original, 'יהוה');
      expect(strong.transliteration, 'Yehovah');
      expect(strong.definition, contains('Dios de Israel'));
      expect(strong.references, isNotEmpty);
    });

    test('Obtener versículos paralelos', () async {
      // Arrange
      final mockResponse = Response(
        data: {
          'parallel': {
            'reference': 'Juan 3:16',
            'verses': [
              {
                'reference': 'Romanos 5:8',
                'text': 'Mas Dios muestra su amor para con nosotros...',
                'relation': 'similar',
              },
              {
                'reference': '1 Juan 4:9',
                'text': 'En esto se mostró el amor de Dios para con nosotros...',
                'relation': 'similar',
              },
            ],
          },
        },
        statusCode: 200,
        requestOptions: RequestOptions(path: '/api/bible/parallel'),
      );

      when(mockDio.get(any, queryParameters: anyNamed('queryParameters')))
          .thenAnswer((_) async => mockResponse);

      // Act
      final parallels = await bibleService.getParallelVerses('Juan', 3, 16);

      // Assert
      expect(parallels, isNotEmpty);
      expect(parallels.length, 2);
      expect(parallels[0].reference, 'Romanos 5:8');
      expect(parallels[0].relation, 'similar');
    });

    test('Obtener versículo del día', () async {
      // Arrange
      final mockResponse = Response(
        data: {
          'verse': {
            'reference': 'Filipenses 4:13',
            'text': 'Todo lo puedo en Cristo que me fortalece.',
            'book': 'Filipenses',
            'chapter': 4,
            'verseNumber': 13,
            'reflection': 'En Cristo encontramos la fortaleza...',
            'date': DateTime.now().toIso8601String(),
          },
        },
        statusCode: 200,
        requestOptions: RequestOptions(path: '/api/bible/verse-of-day'),
      );

      when(mockDio.get(any)).thenAnswer((_) async => mockResponse);

      // Act
      final dailyVerse = await bibleService.getDailyVerse();

      // Assert
      expect(dailyVerse.reference, 'Filipenses 4:13');
      expect(dailyVerse.text, contains('Cristo'));
      expect(dailyVerse.reflection, isNotEmpty);
    });

    test('Manejo de error cuando el servidor no responde', () async {
      // Arrange
      when(mockDio.get(any)).thenThrow(
        DioException(
          requestOptions: RequestOptions(path: '/api/bible/books'),
          message: 'Connection timeout',
          type: DioExceptionType.connectionTimeout,
        ),
      );

      // Act & Assert
      expect(
        () async => await bibleService.getBooks(),
        throwsA(isA<DioException>()),
      );
    });

    test('Guardar versículo en favoritos', () async {
      // Arrange
      final mockResponse = Response(
        data: {
          'success': true,
          'message': 'Versículo guardado en favoritos',
          'favoriteId': '123',
        },
        statusCode: 200,
        requestOptions: RequestOptions(path: '/api/bible/favorites'),
      );

      when(mockDio.post(
        any,
        data: anyNamed('data'),
      )).thenAnswer((_) async => mockResponse);

      // Act
      final result = await bibleService.saveFavoriteVerse(
        'Juan',
        3,
        16,
        'Porque de tal manera amó Dios al mundo...',
      );

      // Assert
      expect(result, true);
      verify(mockDio.post(
        '/api/bible/favorites',
        data: argThat(
          isA<Map>()
              .having((m) => m['book'], 'book', 'Juan')
              .having((m) => m['chapter'], 'chapter', 3)
              .having((m) => m['verse'], 'verse', 16),
          named: 'data',
        ),
      )).called(1);
    });

    test('Obtener historial de lectura', () async {
      // Arrange
      final mockResponse = Response(
        data: {
          'history': [
            {
              'reference': 'Génesis 1',
              'timestamp': DateTime.now().subtract(Duration(days: 1)).toIso8601String(),
              'readTime': 300,
            },
            {
              'reference': 'Juan 1',
              'timestamp': DateTime.now().toIso8601String(),
              'readTime': 250,
            },
          ],
        },
        statusCode: 200,
        requestOptions: RequestOptions(path: '/api/bible/history'),
      );

      when(mockDio.get(any)).thenAnswer((_) async => mockResponse);

      // Act
      final history = await bibleService.getReadingHistory();

      // Assert
      expect(history, isNotEmpty);
      expect(history.length, 2);
      expect(history[1].reference, 'Juan 1');
      expect(history[1].readTime, 250);
    });

    test('Marcar capítulo como leído', () async {
      // Arrange
      final mockResponse = Response(
        data: {
          'success': true,
          'progress': {
            'totalChapters': 1189,
            'readChapters': 150,
            'percentage': 12.6,
          },
        },
        statusCode: 200,
        requestOptions: RequestOptions(path: '/api/bible/mark-read'),
      );

      when(mockDio.post(
        any,
        data: anyNamed('data'),
      )).thenAnswer((_) async => mockResponse);

      // Act
      final progress = await bibleService.markChapterAsRead('Mateo', 5);

      // Assert
      expect(progress.readChapters, 150);
      expect(progress.percentage, 12.6);
      verify(mockDio.post(
        '/api/bible/mark-read',
        data: argThat(
          isA<Map>()
              .having((m) => m['book'], 'book', 'Mateo')
              .having((m) => m['chapter'], 'chapter', 5),
          named: 'data',
        ),
      )).called(1);
    });
  });

  group('BibleService Caching Tests', () {
    test('Segunda llamada a getBooks debe usar caché', () async {
      // Arrange
      final mockResponse = Response(
        data: {'books': []},
        statusCode: 200,
        requestOptions: RequestOptions(path: '/api/bible/books'),
      );

      when(mockDio.get(any)).thenAnswer((_) async => mockResponse);

      // Act
      await bibleService.getBooks();
      await bibleService.getBooks();

      // Assert
      verify(mockDio.get('/api/bible/books')).called(1);
    });

    test('Caché debe expirar después del tiempo configurado', () async {
      // Arrange
      final mockResponse = Response(
        data: {'books': []},
        statusCode: 200,
        requestOptions: RequestOptions(path: '/api/bible/books'),
      );

      when(mockDio.get(any)).thenAnswer((_) async => mockResponse);

      // Act
      await bibleService.getBooks();

      // Simular paso del tiempo
      await Future.delayed(Duration(seconds: 61));

      await bibleService.getBooks();

      // Assert
      verify(mockDio.get('/api/bible/books')).called(2);
    });
  });
}