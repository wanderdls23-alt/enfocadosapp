#!/bin/bash

echo "🔐 Generación de Keystore para Enfocados en Dios TV"
echo "===================================================="
echo ""

# Colores
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
NC='\033[0m'

# Verificar Java/keytool
if ! command -v keytool &> /dev/null; then
    echo -e "${YELLOW}Java/keytool no encontrado. Instalando...${NC}"
    brew install openjdk@11
    sudo ln -sfn /opt/homebrew/opt/openjdk@11/libexec/openjdk.jdk /Library/Java/JavaVirtualMachines/openjdk-11.jdk
    echo 'export PATH="/opt/homebrew/opt/openjdk@11/bin:$PATH"' >> ~/.zshrc
    source ~/.zshrc
fi

KEYSTORE_PATH="android/app/enfocadostv-release-key.jks"
KEY_ALIAS="enfocadostv"

# Verificar si ya existe
if [ -f "$KEYSTORE_PATH" ]; then
    echo -e "${YELLOW}⚠️  Ya existe un keystore en: $KEYSTORE_PATH${NC}"
    read -p "¿Deseas crear uno nuevo? (s/n): " -n 1 -r
    echo
    if [[ ! $REPLY =~ ^[Ss]$ ]]; then
        echo "Usando keystore existente"
        exit 0
    fi
    rm "$KEYSTORE_PATH"
fi

echo -e "${GREEN}Vamos a crear tu keystore de firma${NC}"
echo "Este archivo es MUY IMPORTANTE - sin él no podrás actualizar tu app"
echo ""

# Usar valores predeterminados simples
STORE_PASSWORD="EnfocadosTV2024"
KEY_PASSWORD="EnfocadosTV2024"

echo "Usando contraseña segura predeterminada: EnfocadosTV2024"
echo -e "${RED}⚠️  GUARDA ESTA CONTRASEÑA EN UN LUGAR SEGURO${NC}"
echo ""

# Generar keystore
keytool -genkeypair \
    -v \
    -keystore "$KEYSTORE_PATH" \
    -alias "$KEY_ALIAS" \
    -keyalg RSA \
    -keysize 2048 \
    -validity 10000 \
    -storepass "$STORE_PASSWORD" \
    -keypass "$KEY_PASSWORD" \
    -dname "CN=Enfocados en Dios TV, OU=Ministerio, O=Enfocados en Dios TV, L=Ciudad, ST=Estado, C=US"

if [ $? -eq 0 ]; then
    echo -e "${GREEN}✅ Keystore creado exitosamente${NC}"

    # Crear key.properties
    cat > android/key.properties << EOF
storePassword=$STORE_PASSWORD
keyPassword=$KEY_PASSWORD
keyAlias=$KEY_ALIAS
storeFile=../app/enfocadostv-release-key.jks
EOF

    echo -e "${GREEN}✅ Archivo key.properties creado${NC}"

    # Crear backup
    mkdir -p backups
    cp "$KEYSTORE_PATH" "backups/enfocadostv-release-key-backup-$(date +%Y%m%d).jks"
    echo -e "${GREEN}✅ Backup creado en carpeta backups/${NC}"

    echo ""
    echo -e "${YELLOW}⚠️  IMPORTANTE - GUARDA ESTA INFORMACIÓN:${NC}"
    echo "======================================="
    echo "Keystore: $KEYSTORE_PATH"
    echo "Alias: $KEY_ALIAS"
    echo "Contraseña: $STORE_PASSWORD"
    echo "======================================="
    echo ""
    echo -e "${RED}SIN ESTE KEYSTORE Y CONTRASEÑA NO PODRÁS:${NC}"
    echo "• Actualizar tu app en Google Play"
    echo "• Firmar nuevas versiones"
    echo ""
    echo -e "${GREEN}Recomendaciones:${NC}"
    echo "1. Guarda el archivo keystore en un lugar seguro (Google Drive, USB, etc.)"
    echo "2. Anota la contraseña en un gestor de contraseñas"
    echo "3. NUNCA subas el keystore a GitHub"
    echo ""
    echo -e "${GREEN}✅ Ahora puedes compilar APKs firmados${NC}"
    echo "Ejecuta: ./compile_app.sh y selecciona opción 3 o 4"
else
    echo -e "${RED}❌ Error al crear el keystore${NC}"
    exit 1
fi