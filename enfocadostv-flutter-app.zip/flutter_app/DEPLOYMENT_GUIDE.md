# 🚀 Guía Completa de Deployment - Enfocados en Dios TV App

## 📋 Tabla de Contenidos
1. [Preparación Inicial](#preparación-inicial)
2. [Configuración de Entornos](#configuración-de-entornos)
3. [Deploy Android](#deploy-android)
4. [Deploy iOS](#deploy-ios)
5. [CI/CD con GitHub Actions](#cicd-con-github-actions)
6. [Monitoreo Post-Deploy](#monitoreo-post-deploy)

## 🎯 Preparación Inicial

### 1. Verificar Versiones

```bash
# Flutter
flutter --version  # Debe ser 3.16.0 o superior

# Dart
dart --version     # Debe ser 3.0.0 o superior

# Java (para Android)
java --version     # JDK 11 o superior

# Xcode (para iOS)
xcodebuild -version  # Xcode 15 o superior
```

### 2. Limpiar y Preparar el Proyecto

```bash
# Limpiar cache
flutter clean
flutter pub cache repair

# Obtener dependencias
flutter pub get

# Generar código
flutter pub run build_runner build --delete-conflicting-outputs

# Analizar código
flutter analyze

# Ejecutar tests
flutter test
```

## 🔧 Configuración de Entornos

### Archivos de Configuración

1. **Desarrollo** (`.env.dev`)
```env
API_BASE_URL=https://dev.enfocadosendiostv.com/api
DEBUG_MODE=true
LOG_LEVEL=debug
```

2. **Staging** (`.env.staging`)
```env
API_BASE_URL=https://staging.enfocadosendiostv.com/api
DEBUG_MODE=true
LOG_LEVEL=info
```

3. **Producción** (`.env.prod`)
```env
API_BASE_URL=https://www.enfocadosendiostv.com/api
DEBUG_MODE=false
LOG_LEVEL=error
```

## 📱 Deploy Android

### 1. Configurar Firma de la App

#### Generar Keystore (Primera vez)
```bash
keytool -genkey -v -keystore ~/enfocados-tv.keystore \
  -alias enfocados-tv -keyalg RSA -keysize 2048 -validity 10000
```

#### Configurar key.properties
Crear `android/key.properties`:
```properties
storePassword=tu_contraseña_segura
keyPassword=tu_contraseña_segura
keyAlias=enfocados-tv
storeFile=/Users/tu-usuario/enfocados-tv.keystore
```

### 2. Compilar App Bundle

```bash
# Limpiar build anterior
flutter clean

# Compilar para Play Store
flutter build appbundle \
  --release \
  --flavor prod \
  --obfuscate \
  --split-debug-info=build/symbols \
  -t lib/main.dart
```

El archivo se genera en: `build/app/outputs/bundle/prodRelease/app-prod-release.aab`

### 3. Subir a Google Play Console

1. Acceder a [Google Play Console](https://play.google.com/console)
2. Seleccionar la aplicación
3. Ir a "Versiones" → "Producción"
4. Crear nueva versión
5. Subir el `.aab`
6. Completar notas de la versión
7. Revisar y publicar

### 4. Configurar Play Store

#### App Listing
- **Título**: Enfocados en Dios TV - Biblia
- **Descripción corta**: Biblia, videos cristianos y cursos bíblicos
- **Descripción completa**: [Ver archivo STORE_LISTING.txt]
- **Categoría**: Educación
- **Etiquetas**: Biblia, Cristiano, Educación, Videos

#### Screenshots (Requeridos)
- Teléfono: 2-8 imágenes (1080x1920px)
- Tablet 7": 1-8 imágenes (1080x1920px)
- Tablet 10": 1-8 imágenes (1920x1080px)

## 🍎 Deploy iOS

### 1. Configurar Certificados en Apple Developer

1. Acceder a [Apple Developer](https://developer.apple.com)
2. Crear App ID: `com.enfocadosendiostv.app`
3. Crear certificados:
   - Development
   - Distribution
4. Crear provisioning profiles:
   - Development
   - App Store

### 2. Configurar en Xcode

```bash
# Abrir proyecto en Xcode
cd ios
open Runner.xcworkspace
```

En Xcode:
1. Seleccionar "Runner" en el navegador
2. En "Signing & Capabilities":
   - Team: Seleccionar tu team
   - Bundle Identifier: `com.enfocadosendiostv.app`
   - Signing Certificate: Distribution

### 3. Compilar para App Store

```bash
# Compilar
flutter build ios --release --flavor prod -t lib/main.dart

# Abrir en Xcode
open ios/Runner.xcworkspace
```

En Xcode:
1. Product → Archive
2. Distribuir → App Store Connect
3. Upload

### 4. App Store Connect

1. Acceder a [App Store Connect](https://appstoreconnect.apple.com)
2. Crear nueva versión
3. Completar información:
   - Screenshots
   - Descripción
   - Keywords
   - Categorías
4. Enviar a revisión

### 5. Configurar App Store

#### Información Básica
- **Nombre**: Enfocados en Dios TV
- **Subtítulo**: Biblia y Academia Cristiana
- **Categoría Principal**: Educación
- **Categoría Secundaria**: Libros

#### Keywords
```
biblia,cristiano,dios,jesus,versiculo,oracion,
predica,estudio biblico,cristianismo,fe
```

## 🤖 CI/CD con GitHub Actions

### 1. Workflow para Android

`.github/workflows/android-release.yml`:
```yaml
name: Android Release

on:
  push:
    tags:
      - 'v*'

jobs:
  build:
    runs-on: ubuntu-latest

    steps:
    - uses: actions/checkout@v3

    - uses: actions/setup-java@v3
      with:
        distribution: 'temurin'
        java-version: '11'

    - uses: subosito/flutter-action@v2
      with:
        flutter-version: '3.16.0'

    - name: Install dependencies
      run: flutter pub get

    - name: Build APK
      run: flutter build apk --release --flavor prod

    - name: Build App Bundle
      run: flutter build appbundle --release --flavor prod

    - name: Upload to Play Store
      uses: r0adkll/upload-google-play@v1
      with:
        serviceAccountJsonPlainText: ${{ secrets.SERVICE_ACCOUNT_JSON }}
        packageName: com.enfocadosendiostv.app
        releaseFiles: build/app/outputs/bundle/prodRelease/*.aab
        track: production
```

### 2. Workflow para iOS

`.github/workflows/ios-release.yml`:
```yaml
name: iOS Release

on:
  push:
    tags:
      - 'v*'

jobs:
  build:
    runs-on: macos-latest

    steps:
    - uses: actions/checkout@v3

    - uses: subosito/flutter-action@v2
      with:
        flutter-version: '3.16.0'

    - name: Install dependencies
      run: flutter pub get

    - name: Build iOS
      run: flutter build ios --release --no-codesign

    - name: Deploy to TestFlight
      uses: apple-actions/upload-testflight-build@v1
      with:
        app-path: build/ios/iphoneos/Runner.app
        issuer-id: ${{ secrets.APPSTORE_ISSUER_ID }}
        api-key-id: ${{ secrets.APPSTORE_KEY_ID }}
        api-private-key: ${{ secrets.APPSTORE_PRIVATE_KEY }}
```

## 📊 Monitoreo Post-Deploy

### 1. Firebase Console

Monitorear en [Firebase Console](https://console.firebase.google.com):
- **Crashlytics**: Errores y crashes
- **Analytics**: Uso de la app
- **Performance**: Métricas de rendimiento
- **Remote Config**: Configuración remota

### 2. Play Console

Revisar en [Play Console](https://play.google.com/console):
- Estadísticas de instalación
- Calificaciones y reseñas
- Informes de errores
- Vitals de Android

### 3. App Store Connect

Revisar en [App Store Connect](https://appstoreconnect.apple.com):
- Analytics
- Reseñas y calificaciones
- Crash reports
- TestFlight feedback

## 🐛 Troubleshooting

### Problemas Comunes Android

1. **Error de firma**
```bash
# Verificar keystore
keytool -list -v -keystore ~/enfocados-tv.keystore
```

2. **Error de minSdkVersion**
```gradle
// android/app/build.gradle
defaultConfig {
    minSdkVersion 21  // Mínimo recomendado
}
```

### Problemas Comunes iOS

1. **Error de certificados**
```bash
# Limpiar certificados
rm -rf ~/Library/MobileDevice/Provisioning\ Profiles/
# Descargar nuevamente desde Apple Developer
```

2. **Error de pods**
```bash
cd ios
pod cache clean --all
rm -rf Pods Podfile.lock
pod install
```

## 📝 Checklist Pre-Deploy

### Android
- [ ] Incrementar versionCode y versionName
- [ ] Probar en dispositivo físico
- [ ] Verificar ProGuard rules
- [ ] Generar y subir símbolos a Crashlytics
- [ ] Verificar permisos en AndroidManifest
- [ ] Screenshots actualizados en Play Store

### iOS
- [ ] Incrementar version y build number
- [ ] Probar en dispositivo físico
- [ ] Verificar Info.plist
- [ ] Configurar App Transport Security
- [ ] Screenshots actualizados en App Store
- [ ] Probar en TestFlight primero

## 🔄 Versionado

Seguir [Semantic Versioning](https://semver.org/):
- **MAJOR.MINOR.PATCH** (ej: 1.2.3)
- MAJOR: Cambios incompatibles
- MINOR: Nueva funcionalidad compatible
- PATCH: Corrección de bugs

## 📧 Contacto y Soporte

Para problemas de deployment:
- Email: dev@enfocadosendiostv.com
- Slack: #mobile-deployment
- Documentación interna: wiki.enfocadosendiostv.com

---

**Última actualización**: Diciembre 2024
**Versión del documento**: 1.0.0