#!/bin/bash

# Script para compilar la app Android para producción
# Ejecutar desde la raíz del proyecto Flutter

echo "📱 Build de Enfocados en Dios TV para Android"
echo "=============================================="

# Colores
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

# Configuración
BUILD_TYPE="appbundle" # appbundle o apk
VERSION_NAME=$(grep 'version:' pubspec.yaml | sed 's/version: //')

# Función para mostrar progreso
show_progress() {
    echo -e "${BLUE}⏳ $1...${NC}"
}

# Función para mostrar éxito
show_success() {
    echo -e "${GREEN}✅ $1${NC}"
}

# Función para mostrar error
show_error() {
    echo -e "${RED}❌ $1${NC}"
    exit 1
}

# Verificar Flutter
if ! command -v flutter &> /dev/null; then
    show_error "Flutter no está instalado"
fi

# Limpiar build anterior
show_progress "Limpiando builds anteriores"
flutter clean
show_success "Build limpio"

# Obtener dependencias
show_progress "Obteniendo dependencias"
flutter pub get
show_success "Dependencias instaladas"

# Generar código (freezed, json_serializable, etc)
show_progress "Generando código"
flutter pub run build_runner build --delete-conflicting-outputs
show_success "Código generado"

# Verificar keystore
if [ ! -f "android/key.properties" ]; then
    show_error "No se encontró android/key.properties. Ejecuta primero ./scripts/generate_keystore.sh"
fi

if [ ! -f "android/app/enfocadostv-release-key.jks" ]; then
    show_error "No se encontró el keystore. Ejecuta primero ./scripts/generate_keystore.sh"
fi

# Incrementar version code
show_progress "Verificando versión"
echo "📦 Versión actual: $VERSION_NAME"

# Seleccionar tipo de build
echo -e "\n${YELLOW}Selecciona el tipo de build:${NC}"
echo "1) App Bundle (.aab) - Recomendado para Play Store"
echo "2) APK - Para distribución directa"
echo "3) Ambos"
read -p "Opción [1-3]: " BUILD_OPTION

case $BUILD_OPTION in
    1)
        BUILD_TYPE="appbundle"
        ;;
    2)
        BUILD_TYPE="apk"
        ;;
    3)
        BUILD_TYPE="both"
        ;;
    *)
        BUILD_TYPE="appbundle"
        ;;
esac

# Compilar App Bundle
if [ "$BUILD_TYPE" = "appbundle" ] || [ "$BUILD_TYPE" = "both" ]; then
    show_progress "Compilando App Bundle para release"
    flutter build appbundle \
        --release \
        --obfuscate \
        --split-debug-info=build/app/outputs/symbols \
        --dart-define=ENVIRONMENT=production

    if [ $? -eq 0 ]; then
        show_success "App Bundle compilado exitosamente"
        AAB_PATH="build/app/outputs/bundle/release/app-release.aab"
        AAB_SIZE=$(du -h "$AAB_PATH" | cut -f1)
        echo -e "${GREEN}📦 Archivo generado:${NC}"
        echo "   Ubicación: $AAB_PATH"
        echo "   Tamaño: $AAB_SIZE"
    else
        show_error "Error al compilar App Bundle"
    fi
fi

# Compilar APK
if [ "$BUILD_TYPE" = "apk" ] || [ "$BUILD_TYPE" = "both" ]; then
    show_progress "Compilando APK para release"

    # Preguntar por split APKs
    read -p "¿Generar APKs separados por arquitectura? (s/n): " -n 1 -r
    echo

    if [[ $REPLY =~ ^[Ss]$ ]]; then
        flutter build apk \
            --release \
            --split-per-abi \
            --obfuscate \
            --split-debug-info=build/app/outputs/symbols \
            --dart-define=ENVIRONMENT=production
    else
        flutter build apk \
            --release \
            --obfuscate \
            --split-debug-info=build/app/outputs/symbols \
            --dart-define=ENVIRONMENT=production
    fi

    if [ $? -eq 0 ]; then
        show_success "APK compilado exitosamente"
        APK_PATH="build/app/outputs/flutter-apk/"
        echo -e "${GREEN}📦 Archivos generados en:${NC}"
        echo "   $APK_PATH"
        ls -lh "$APK_PATH"*.apk
    else
        show_error "Error al compilar APK"
    fi
fi

# Crear carpeta de distribución
DIST_DIR="dist/android/$(date +%Y%m%d_%H%M%S)"
mkdir -p "$DIST_DIR"

# Copiar archivos
show_progress "Organizando archivos de distribución"
if [ "$BUILD_TYPE" = "appbundle" ] || [ "$BUILD_TYPE" = "both" ]; then
    cp "$AAB_PATH" "$DIST_DIR/"
fi

if [ "$BUILD_TYPE" = "apk" ] || [ "$BUILD_TYPE" = "both" ]; then
    cp build/app/outputs/flutter-apk/*.apk "$DIST_DIR/" 2>/dev/null
fi

# Copiar símbolos para Crashlytics
if [ -d "build/app/outputs/symbols" ]; then
    cp -r build/app/outputs/symbols "$DIST_DIR/"
    show_success "Símbolos de debug copiados"
fi

# Generar reporte
REPORT_FILE="$DIST_DIR/build_report.txt"
cat > "$REPORT_FILE" << EOL
Build Report - Enfocados en Dios TV
====================================
Fecha: $(date)
Versión: $VERSION_NAME
Tipo de Build: $BUILD_TYPE

Archivos generados:
$(ls -lh "$DIST_DIR"/*.{aab,apk} 2>/dev/null)

Notas:
- App Bundle (.aab) para subir a Google Play Console
- APK para pruebas o distribución directa
- Símbolos de debug para Crashlytics en /symbols

Próximos pasos:
1. Subir .aab a Google Play Console
2. Configurar release en la consola
3. Completar información de la tienda
4. Enviar para revisión
EOL

show_success "Reporte generado: $REPORT_FILE"

# Resumen final
echo ""
echo "=============================================="
echo -e "${GREEN}🎉 Build completado exitosamente${NC}"
echo "=============================================="
echo -e "📁 Archivos en: ${YELLOW}$DIST_DIR${NC}"
echo ""
echo "📱 Para probar el APK en un dispositivo:"
echo "   adb install $DIST_DIR/*.apk"
echo ""
echo "📤 Para subir a Play Store:"
echo "   1. Ve a https://play.google.com/console"
echo "   2. Sube el archivo .aab"
echo ""

# Abrir carpeta de distribución
if [[ "$OSTYPE" == "darwin"* ]]; then
    open "$DIST_DIR"
elif [[ "$OSTYPE" == "linux-gnu"* ]]; then
    xdg-open "$DIST_DIR"
fi