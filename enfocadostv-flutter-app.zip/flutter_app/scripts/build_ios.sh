#!/bin/bash

# Script para compilar la app iOS para producción
# Ejecutar desde la raíz del proyecto Flutter en macOS

echo "🍎 Build de Enfocados en Dios TV para iOS"
echo "=========================================="

# Colores
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

# Verificar que estamos en macOS
if [[ "$OSTYPE" != "darwin"* ]]; then
    echo -e "${RED}❌ Este script solo funciona en macOS${NC}"
    exit 1
fi

# Verificar Xcode
if ! command -v xcodebuild &> /dev/null; then
    echo -e "${RED}❌ Xcode no está instalado${NC}"
    exit 1
fi

# Verificar CocoaPods
if ! command -v pod &> /dev/null; then
    echo -e "${YELLOW}⚠️  CocoaPods no está instalado. Instalando...${NC}"
    sudo gem install cocoapods
fi

# Función para mostrar progreso
show_progress() {
    echo -e "${BLUE}⏳ $1...${NC}"
}

# Función para mostrar éxito
show_success() {
    echo -e "${GREEN}✅ $1${NC}"
}

# Función para mostrar error
show_error() {
    echo -e "${RED}❌ $1${NC}"
    exit 1
}

# Limpiar build anterior
show_progress "Limpiando builds anteriores"
flutter clean
cd ios && rm -rf Pods Podfile.lock && cd ..
show_success "Build limpio"

# Obtener dependencias
show_progress "Obteniendo dependencias de Flutter"
flutter pub get
show_success "Dependencias de Flutter instaladas"

# Generar código
show_progress "Generando código"
flutter pub run build_runner build --delete-conflicting-outputs
show_success "Código generado"

# Instalar pods
show_progress "Instalando CocoaPods"
cd ios
pod install --repo-update
cd ..
show_success "CocoaPods instalados"

# Configurar certificados
echo -e "\n${YELLOW}📱 Configuración de certificados${NC}"
echo "================================="
echo "Asegúrate de tener configurado en Xcode:"
echo "1. Apple Developer Account"
echo "2. Certificados de desarrollo y distribución"
echo "3. Provisioning Profiles"
echo "4. App ID configurado en developer.apple.com"
echo ""
read -p "¿Tienes todo configurado? (s/n): " -n 1 -r
echo

if [[ ! $REPLY =~ ^[Ss]$ ]]; then
    echo -e "${RED}Configura los certificados en Xcode primero${NC}"
    echo "1. Abre ios/Runner.xcworkspace en Xcode"
    echo "2. Selecciona el target Runner"
    echo "3. En Signing & Capabilities, configura tu Team"
    echo "4. Selecciona los provisioning profiles correctos"
    exit 1
fi

# Seleccionar tipo de build
echo -e "\n${YELLOW}Selecciona el tipo de build:${NC}"
echo "1) Desarrollo (Debug)"
echo "2) TestFlight / App Store (Release)"
echo "3) Ad-Hoc (Distribución directa)"
read -p "Opción [1-3]: " BUILD_OPTION

case $BUILD_OPTION in
    1)
        BUILD_CONFIG="Debug"
        ;;
    2)
        BUILD_CONFIG="Release"
        ;;
    3)
        BUILD_CONFIG="Ad-Hoc"
        ;;
    *)
        BUILD_CONFIG="Release"
        ;;
esac

# Incrementar build number
show_progress "Incrementando build number"
BUILD_NUMBER=$(date +%Y%m%d%H%M)
/usr/libexec/PlistBuddy -c "Set :CFBundleVersion $BUILD_NUMBER" ios/Runner/Info.plist
show_success "Build number: $BUILD_NUMBER"

# Compilar
if [ "$BUILD_CONFIG" = "Debug" ]; then
    show_progress "Compilando iOS app (Debug)"
    flutter build ios --debug
else
    show_progress "Compilando iOS app (Release)"
    flutter build ios --release --obfuscate --split-debug-info=build/ios/symbols
fi

if [ $? -ne 0 ]; then
    show_error "Error al compilar la app"
fi

show_success "App compilada exitosamente"

# Crear IPA si es Release
if [ "$BUILD_CONFIG" != "Debug" ]; then
    echo -e "\n${YELLOW}📦 Creando archivo IPA${NC}"
    echo "========================"

    cd ios

    # Limpiar y archivar
    show_progress "Archivando app"
    xcodebuild -workspace Runner.xcworkspace \
               -scheme Runner \
               -configuration Release \
               -archivePath build/Runner.xcarchive \
               archive

    if [ $? -ne 0 ]; then
        cd ..
        show_error "Error al archivar la app"
    fi

    # Exportar IPA
    show_progress "Exportando IPA"

    # Crear ExportOptions.plist
    cat > ExportOptions.plist << EOL
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
    <key>method</key>
    <string>app-store</string>
    <key>teamID</key>
    <string>YOUR_TEAM_ID</string>
    <key>uploadSymbols</key>
    <true/>
    <key>uploadBitcode</key>
    <false/>
    <key>compileBitcode</key>
    <false/>
    <key>signingStyle</key>
    <string>automatic</string>
</dict>
</plist>
EOL

    xcodebuild -exportArchive \
               -archivePath build/Runner.xcarchive \
               -exportPath build/ios \
               -exportOptionsPlist ExportOptions.plist

    if [ $? -ne 0 ]; then
        cd ..
        show_error "Error al exportar IPA"
    fi

    cd ..
    show_success "IPA creado exitosamente"
fi

# Crear carpeta de distribución
DIST_DIR="dist/ios/$(date +%Y%m%d_%H%M%S)"
mkdir -p "$DIST_DIR"

# Copiar archivos
if [ "$BUILD_CONFIG" = "Debug" ]; then
    cp -r build/ios/iphoneos/*.app "$DIST_DIR/" 2>/dev/null
else
    cp build/ios/*.ipa "$DIST_DIR/" 2>/dev/null
    cp -r build/ios/Runner.xcarchive "$DIST_DIR/" 2>/dev/null
    cp -r build/ios/symbols "$DIST_DIR/" 2>/dev/null
fi

# Generar reporte
REPORT_FILE="$DIST_DIR/build_report.txt"
cat > "$REPORT_FILE" << EOL
Build Report - Enfocados en Dios TV iOS
========================================
Fecha: $(date)
Build Number: $BUILD_NUMBER
Configuración: $BUILD_CONFIG

Archivos generados:
$(ls -lh "$DIST_DIR"/*)

Próximos pasos para TestFlight/App Store:
1. Abrir Xcode
2. Window > Organizer
3. Seleccionar el archive
4. Distribute App
5. App Store Connect
6. Upload

O usar Transporter:
1. Descargar Transporter de Mac App Store
2. Arrastrar el archivo .ipa
3. Deliver

Alternativamente con xcrun:
xcrun altool --upload-app -f "$DIST_DIR/*.ipa" -u "APPLE_ID" -p "APP_SPECIFIC_PASSWORD"
EOL

show_success "Reporte generado: $REPORT_FILE"

# Resumen final
echo ""
echo "=========================================="
echo -e "${GREEN}🎉 Build completado exitosamente${NC}"
echo "=========================================="
echo -e "📁 Archivos en: ${YELLOW}$DIST_DIR${NC}"
echo ""

if [ "$BUILD_CONFIG" != "Debug" ]; then
    echo "📤 Para subir a TestFlight:"
    echo "   1. Abre Xcode > Window > Organizer"
    echo "   2. Selecciona el archive y click en 'Distribute App'"
    echo ""
    echo "📱 O usa Transporter (más fácil):"
    echo "   1. Abre Transporter"
    echo "   2. Arrastra el archivo .ipa"
    echo ""
fi

# Abrir carpeta
open "$DIST_DIR"