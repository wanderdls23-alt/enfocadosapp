#!/bin/bash

# Script para generar el keystore para firma de la app Android
# Ejecutar desde la raíz del proyecto Flutter

echo "🔐 Generando Keystore para Enfocados en Dios TV"
echo "================================================"

# Colores para output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

# Configuración
KEYSTORE_NAME="enfocadostv-release-key.jks"
KEY_ALIAS="enfocadostv"
VALIDITY_DAYS=10000
KEYSTORE_PATH="android/app/$KEYSTORE_NAME"

# Verificar si ya existe el keystore
if [ -f "$KEYSTORE_PATH" ]; then
    echo -e "${YELLOW}⚠️  El keystore ya existe en: $KEYSTORE_PATH${NC}"
    read -p "¿Deseas sobrescribirlo? (s/n): " -n 1 -r
    echo
    if [[ ! $REPLY =~ ^[Ss]$ ]]; then
        echo -e "${RED}❌ Operación cancelada${NC}"
        exit 1
    fi
    rm "$KEYSTORE_PATH"
fi

# Información para el certificado
echo -e "\n${GREEN}📝 Ingresa la información para el certificado:${NC}"
echo "-----------------------------------------------"

read -p "Nombre y Apellido (CN): " CN
CN=${CN:-"Enfocados en Dios TV"}

read -p "Unidad Organizacional (OU): " OU
OU=${OU:-"Desarrollo"}

read -p "Organización (O): " O
O=${O:-"Enfocados en Dios TV"}

read -p "Ciudad (L): " L
L=${L:-"Ciudad"}

read -p "Estado/Provincia (ST): " ST
ST=${ST:-"Estado"}

read -p "Código de País (C) [2 letras]: " C
C=${C:-"US"}

# Contraseña del keystore
echo -e "\n${GREEN}🔑 Configuración de seguridad:${NC}"
echo "--------------------------------"
read -s -p "Contraseña para el keystore (mínimo 6 caracteres): " STORE_PASSWORD
echo
read -s -p "Confirma la contraseña: " STORE_PASSWORD_CONFIRM
echo

if [ "$STORE_PASSWORD" != "$STORE_PASSWORD_CONFIRM" ]; then
    echo -e "${RED}❌ Las contraseñas no coinciden${NC}"
    exit 1
fi

if [ ${#STORE_PASSWORD} -lt 6 ]; then
    echo -e "${RED}❌ La contraseña debe tener al menos 6 caracteres${NC}"
    exit 1
fi

# Generar el keystore
echo -e "\n${YELLOW}⏳ Generando keystore...${NC}"

keytool -genkeypair \
    -v \
    -keystore "$KEYSTORE_PATH" \
    -alias "$KEY_ALIAS" \
    -keyalg RSA \
    -keysize 2048 \
    -validity $VALIDITY_DAYS \
    -storepass "$STORE_PASSWORD" \
    -keypass "$STORE_PASSWORD" \
    -dname "CN=$CN, OU=$OU, O=$O, L=$L, ST=$ST, C=$C"

if [ $? -eq 0 ]; then
    echo -e "${GREEN}✅ Keystore generado exitosamente${NC}"
    echo -e "📍 Ubicación: $KEYSTORE_PATH"

    # Actualizar key.properties
    KEY_PROPERTIES="android/key.properties"
    echo -e "\n${YELLOW}📝 Actualizando $KEY_PROPERTIES...${NC}"

    cat > "$KEY_PROPERTIES" << EOL
storePassword=$STORE_PASSWORD
keyPassword=$STORE_PASSWORD
keyAlias=$KEY_ALIAS
storeFile=../app/$KEYSTORE_NAME
EOL

    echo -e "${GREEN}✅ Archivo key.properties actualizado${NC}"

    # Añadir al .gitignore
    if ! grep -q "key.properties" .gitignore 2>/dev/null; then
        echo -e "\n# Android signing" >> .gitignore
        echo "android/key.properties" >> .gitignore
        echo "android/app/*.jks" >> .gitignore
        echo "android/app/*.keystore" >> .gitignore
        echo -e "${GREEN}✅ Archivos sensibles añadidos a .gitignore${NC}"
    fi

    # Instrucciones importantes
    echo -e "\n${YELLOW}⚠️  IMPORTANTE:${NC}"
    echo "================================================"
    echo "1. Guarda el keystore en un lugar seguro"
    echo "2. NUNCA subas el keystore a repositorios públicos"
    echo "3. Haz backup del keystore - si lo pierdes, no podrás actualizar la app"
    echo "4. Guarda la contraseña en un gestor de contraseñas seguro"
    echo ""
    echo "📱 Para compilar en release mode:"
    echo "   flutter build appbundle --release"
    echo ""
    echo "📤 El archivo .aab estará en:"
    echo "   build/app/outputs/bundle/release/app-release.aab"

else
    echo -e "${RED}❌ Error al generar el keystore${NC}"
    exit 1
fi